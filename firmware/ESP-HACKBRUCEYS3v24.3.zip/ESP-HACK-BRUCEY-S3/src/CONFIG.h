#ifndef PIN_H
#define PIN_H

// Brucey ESP32-S3 N16R8
// Display
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADR 0x3C
#define OLED_RESET -1
#define OLED_SCL 18
#define OLED_SDA 17

// Buttons (active-low with pull-ups)
#define BUTTON_UP 1
#define BUTTON_DOWN 4
#define BUTTON_OK 7
#define BUTTON_BACK 5
#define BUTTON_RIGHT 6

// Shared SPI bus
#define SHARED_SPI_SCK 12
#define SHARED_SPI_MOSI 11
#define SHARED_SPI_MISO 13
#define SD_MISO_SEPARATE 3

// SD Card
#define SD_CS 46
#define SD_MOSI SHARED_SPI_MOSI
#define SD_CLK SHARED_SPI_SCK
#define SD_MISO SD_MISO_SEPARATE

// CC1101
#define CC1101_GDO0 2
#define CC1101_CS 10
#define CC1101_SCK SHARED_SPI_SCK
#define CC1101_MOSI SHARED_SPI_MOSI
#define CC1101_MISO SHARED_SPI_MISO

// NRF24L01+
#define NRF24_CE 15
#define NRF24_CSN 14
#define NRF24_SCK SHARED_SPI_SCK
#define NRF24_MOSI SHARED_SPI_MOSI
#define NRF24_MISO SHARED_SPI_MISO

// Infrared
#define IR_TRANSMITTER 9
#define IR_RECIVER 8

// Generic GPIO slots used by ESP-HACK's NRF/iButton configuration UI.
// Defaults are mapped to the actual NRF24 wiring.
#define GPIO_A NRF24_CE
#define GPIO_B NRF24_CSN
#define GPIO_C NRF24_SCK
#define GPIO_D NRF24_MOSI
#define GPIO_E NRF24_MISO
#define GPIO_F 3

// Firmware version
static const char* FIRMWARE = "v1.3-BRUCEY-S3-V24.3-FINAL";

#endif
