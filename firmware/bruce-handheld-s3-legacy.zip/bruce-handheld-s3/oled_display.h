#pragma once

#include <Arduino.h>
#include <Wire.h>
#include <vector>

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 oled;

bool initBruceOLED();
void oledSplash();

void oledMessage(const String &title, const String &message);

void oledDrawMenu(const std::vector<String> &labels, int selectedIndex, const char *title);
