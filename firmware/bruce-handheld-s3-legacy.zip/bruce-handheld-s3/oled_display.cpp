#include "oled_display.h"
#include "pins_arduino.h"

Adafruit_SSD1306 oled(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);

static uint8_t oledAddress = 0x3C;

bool initBruceOLED() {

    Serial.println("[OLED] Initializing...");

    Wire.begin(SYS_I2C_SDA, SYS_I2C_SCL);

    Wire.setClock(100000);

    delay(100);

    // Scan for 0x3C / 0x3D
    bool found = false;

    for (uint8_t addr : {0x3C, 0x3D}) {

        Wire.beginTransmission(addr);

        if (Wire.endTransmission() == 0) {

            oledAddress = addr;
            found = true;

            Serial.printf("[OLED] Found SSD1306 at 0x%02X\n", addr);

            break;
        }
    }

    if (!found) {

        Serial.println("[OLED] SSD1306 not detected");

        return false;
    }

    if (!oled.begin(SSD1306_SWITCHCAPVCC, oledAddress)) {

        Serial.println("[OLED] begin() failed");

        return false;
    }

    oled.clearDisplay();

    oled.setTextColor(SSD1306_WHITE);

    oled.setTextSize(1);
    oled.setTextWrap(false);

    oled.display();

    Serial.println("[OLED] Ready");

    return true;
}

void oledSplash() {

    oled.clearDisplay();

    oled.setTextColor(SSD1306_WHITE);

    oled.setTextSize(2);
    oled.setCursor(18, 6);
    oled.println("BRUCEY x)");

    oled.setTextSize(1);

    oled.setCursor(18, 34);
    oled.println("ESP32-S3");

    oled.setCursor(20, 50);
    oled.println("HANDHELD");

    oled.display();
}

void oledMessage(const String &title, const String &message) {

    oled.clearDisplay();

    oled.setTextSize(1);
    oled.setTextColor(SSD1306_WHITE);

    oled.setCursor(0, 0);
    oled.println(title);

    oled.drawLine(0, 10, 127, 10, SSD1306_WHITE);

    oled.setCursor(0, 15);

    oled.println(message);

    oled.display();
}

void oledDrawMenu(const std::vector<String> &labels, int selectedIndex, const char *title) {

    if (labels.empty()) { return; }

    oled.clearDisplay();

    oled.setTextSize(1);

    // ---------------------------
    // Header
    // ---------------------------

    oled.setTextColor(SSD1306_WHITE);

    oled.setCursor(1, 1);

    String header = (title && strlen(title)) ? String(title) : String("BRUCE");

    if (header.length() > 20) { header = header.substring(0, 20); }

    oled.print(header);

    oled.drawLine(0, 10, 127, 10, SSD1306_WHITE);

    // ---------------------------
    // Menu window
    // ---------------------------

    const int visibleRows = 5;

    int first = 0;

    if (selectedIndex >= visibleRows) { first = selectedIndex - visibleRows + 1; }

    if (first + visibleRows > (int)labels.size()) { first = max(0, (int)labels.size() - visibleRows); }

    for (int row = 0; row < visibleRows; row++) {

        int item = first + row;

        if (item >= (int)labels.size()) { break; }

        int y = 13 + row * 10;

        bool selected = item == selectedIndex;

        if (selected) {

            oled.fillRect(0, y - 1, 128, 9, SSD1306_WHITE);

            oled.setTextColor(SSD1306_BLACK);

        } else {

            oled.setTextColor(SSD1306_WHITE);
        }

        oled.setCursor(2, y);

        String text = labels[item];

        if (text.length() > 20) { text = text.substring(0, 19); }

        if (selected) {
            oled.print(">");
        } else {
            oled.print(" ");
        }

        oled.print(text);
    }

    oled.display();
}
