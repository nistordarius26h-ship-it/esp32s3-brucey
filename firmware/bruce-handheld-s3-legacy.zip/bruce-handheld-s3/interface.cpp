#include <Arduino.h>
#include <Wire.h>

#include "oled_display.h"
#include "pins_arduino.h"

#include "core/configPins.h"
#include <globals.h>
#include <interface.h>

#include "core/powerSave.h"
#include "core/utils.h"

void _setup_gpio() {

    Serial.println("[Bruce Handheld] GPIO setup");

    // Buttons
    pinMode(UP_BTN, INPUT_PULLUP);
    pinMode(DW_BTN, INPUT_PULLUP);
    pinMode(L_BTN, INPUT_PULLUP);
    pinMode(R_BTN, INPUT_PULLUP);
    pinMode(SEL_BTN, INPUT_PULLUP);

    // SPI chip selects
    pinMode(CC1101_SS_PIN, OUTPUT);
    pinMode(NRF24_SS_PIN, OUTPUT);
    pinMode(SDCARD_CS, OUTPUT);

    digitalWrite(CC1101_SS_PIN, HIGH);
    digitalWrite(NRF24_SS_PIN, HIGH);
    digitalWrite(SDCARD_CS, HIGH);

    // NRF24 CE
    pinMode(NRF24_CE_PIN, OUTPUT);
    digitalWrite(NRF24_CE_PIN, LOW);

    // CC1101
    pinMode(CC1101_GDO0_PIN, INPUT);

    // IR
    pinMode(TXLED, OUTPUT);
    digitalWrite(TXLED, LOW);

    pinMode(RXLED, INPUT);

    // I2C
    Wire.begin(SYS_I2C_SDA, SYS_I2C_SCL);

    // ======================================================
    // Force Bruce runtime configuration to our PCB
    // ======================================================

    bruceConfigPins.i2c_bus = {GPIO_NUM_17, GPIO_NUM_18};

    bruceConfigPins.CC1101_bus = {
        GPIO_NUM_12, // SCK
        GPIO_NUM_13, // MISO
        GPIO_NUM_11, // MOSI
        GPIO_NUM_10, // CS
        GPIO_NUM_2,  // GDO0
        GPIO_NUM_NC
    };

    bruceConfigPins.NRF24_bus = {
        GPIO_NUM_12, // SCK
        GPIO_NUM_13, // MISO
        GPIO_NUM_11, // MOSI
        GPIO_NUM_14, // CSN
        GPIO_NUM_15, // CE
        GPIO_NUM_NC
    };

    bruceConfigPins.SDCARD_bus = {
        GPIO_NUM_12, // SCK
        GPIO_NUM_13, // MISO
        GPIO_NUM_11, // MOSI
        GPIO_NUM_46, // CS
        GPIO_NUM_NC,
        GPIO_NUM_NC
    };

    bruceConfigPins.irTx = 9;
    bruceConfigPins.irRx = 8;

    bruceConfigPins.rfModule = CC1101_SPI_MODULE;

    bruceConfigPins.rfidModule = PN532_I2C_MODULE;

    Serial.println("[Bruce Handheld] Custom runtime pins loaded");

    Serial.printf("I2C SDA=%d SCL=%d\n", bruceConfigPins.i2c_bus.sda, bruceConfigPins.i2c_bus.scl);

    Serial.printf(
        "CC1101 SCK=%d MISO=%d MOSI=%d CS=%d GDO0=%d\n",
        bruceConfigPins.CC1101_bus.sck,
        bruceConfigPins.CC1101_bus.miso,
        bruceConfigPins.CC1101_bus.mosi,
        bruceConfigPins.CC1101_bus.cs,
        bruceConfigPins.CC1101_bus.io0
    );

    Serial.printf(
        "NRF24 SCK=%d MISO=%d MOSI=%d CS=%d CE=%d\n",
        bruceConfigPins.NRF24_bus.sck,
        bruceConfigPins.NRF24_bus.miso,
        bruceConfigPins.NRF24_bus.mosi,
        bruceConfigPins.NRF24_bus.cs,
        bruceConfigPins.NRF24_bus.io0
    );

    // SSD1306
    if (initBruceOLED()) {
        oledSplash();
        delay(1000);
    }
}

void _post_setup_gpio() {}

void InputHandler(void) {

    static unsigned long lastPress = 0;

    checkPowerSaveTime();

    if (millis() - lastPress < 180) { return; }

    bool up = digitalRead(UP_BTN) == BTN_ACT;

    bool down = digitalRead(DW_BTN) == BTN_ACT;

    bool left = digitalRead(L_BTN) == BTN_ACT;

    bool right = digitalRead(R_BTN) == BTN_ACT;

    bool middle = digitalRead(SEL_BTN) == BTN_ACT;

    if (!(up || down || left || right || middle)) { return; }

    if (wakeUpScreen()) {
        lastPress = millis();
        return;
    }

    AnyKeyPress = true;
    lastPress = millis();

    // LEFT = BACK
    if (left) {
        EscPress = true;
        return;
    }

    // UP = previous menu item
    if (up) {
        PrevPress = true;
        return;
    }

    // DOWN = next menu item
    if (down) {
        NextPress = true;
        return;
    }

    // RIGHT = ENTER / SELECT
    if (right) {
        SelPress = true;
        return;
    }

    // MIDDLE = ENTER / SELECT too
    if (middle) {
        SelPress = true;
        return;
    }
}
