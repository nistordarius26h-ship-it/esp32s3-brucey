#pragma once

// ======================================================
// Bruce Handheld S3 - custom hardware definitions
// ESP32-S3 N16R8
// ======================================================

// ======================================================
// I2C
// SSD1306 + PN532
// ======================================================

#define GROVE_SDA 17
#define GROVE_SCL 18

#define SYS_I2C_SDA 17
#define SYS_I2C_SCL 18

// ======================================================
// SSD1306
// ======================================================

#define HAS_SCREEN 1
#define HAS_SSD1306 1

#define OLED_WIDTH   128
#define OLED_HEIGHT  64
#define OLED_ADDRESS 0x3C

// ======================================================
// Shared SPI
// ======================================================

#define SPI_MOSI_PIN 11
#define SPI_SCK_PIN  12
#define SPI_MISO_PIN 13

// Do NOT define static MOSI/MISO/SCK here.
// ESP-General already provides them.

// ======================================================
// CC1101
// ======================================================

#define USE_CC1101_VIA_SPI

#define CC1101_SS_PIN    10
#define CC1101_GDO0_PIN   2

#define CC1101_MOSI_PIN SPI_MOSI_PIN
#define CC1101_MISO_PIN SPI_MISO_PIN
#define CC1101_SCK_PIN  SPI_SCK_PIN

// ======================================================
// NRF24L01+ PA/LNA
// ======================================================

#define USE_NRF24_VIA_SPI

#define NRF24_SS_PIN 14
#define NRF24_CE_PIN 15

#define NRF24_MOSI_PIN SPI_MOSI_PIN
#define NRF24_MISO_PIN SPI_MISO_PIN
#define NRF24_SCK_PIN  SPI_SCK_PIN

// ======================================================
// MicroSD
// ======================================================

#define SDCARD_CS   46
#define SDCARD_MOSI SPI_MOSI_PIN
#define SDCARD_MISO SPI_MISO_PIN
#define SDCARD_SCK  SPI_SCK_PIN

// ======================================================
// Infrared
// ======================================================

#define TXLED 9
#define RXLED 8

#define IR_TX_PINS {{"Internal IR", TXLED}}
#define IR_RX_PINS {{"Internal IR", RXLED}}

// ======================================================
// Five buttons
// Active LOW -> button connects GPIO to GND
// ======================================================

#define HAS_5_BUTTONS

#define UP_BTN   1
#define DW_BTN   4
#define L_BTN    5
#define R_BTN    6
#define SEL_BTN  7

#define BTN_ACT LOW
#define BTN_ALIAS "\"OK\""
