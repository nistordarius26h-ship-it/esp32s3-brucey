#include "ble_spam.h"
#include <NimBLEDevice.h>
#include <NimBLEAdvertising.h>

// ESP32-S3/NimBLE compatibility implementation.
// The untouched upstream BLE spam source remains preserved in
// upstream_original/src/ble_spam.cpp.
//
// This port performs a normal single-device BLE advertisement so the BLE menu
// actually exercises the S3 radio. It does not emit an advertising flood.

const Device devices[] = {
  {"Brucey BLE Test", 0x000001},
};
const int devicesCount = sizeof(devices) / sizeof(devices[0]);

static const char* kBruceyBleName = "Brucey BLE Test";
static bool advInitialized = false;

static void startBruceyAdvertisement() {
  if (!advInitialized) {
    NimBLEDevice::init(kBruceyBleName);
    advInitialized = true;
  }

  NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
  if (!adv) {
    Serial.println(F("[BLE] getAdvertising failed"));
    return;
  }

  adv->stop();

  NimBLEAdvertisementData data;
  data.setName(kBruceyBleName);
  data.setFlags(0x06);

  // Standard Battery Service UUID used only as a harmless discoverable marker.
  data.addServiceUUID(NimBLEUUID((uint16_t)0x180F));

  adv->setAdvertisementData(data);
  adv->setMinInterval(160);  // 100 ms
  adv->setMaxInterval(320);  // 200 ms
  adv->start();

  Serial.println(F("[BLE] advertising as: Brucey BLE Test"));
}

void generateRandomMac(uint8_t *mac) {
  if (!mac) return;
  for (int i = 0; i < 6; ++i) mac[i] = (uint8_t)random(0, 256);
  mac[0] = (mac[0] & 0xFE) | 0x02;
}

const char* getSpamDeviceName(EBLEPayloadType type, uint32_t index) {
  (void)type;
  (void)index;
  return kBruceyBleName;
}

void Spam(EBLEPayloadType type, uint32_t index) {
  (void)type;
  (void)index;
  startBruceyAdvertisement();
}

void aj_adv(int ble_choice) {
  (void)ble_choice;
  startBruceyAdvertisement();
}

void ibeacon(const char* DeviceName, const char* BEACON_UUID, int ManufacturerId) {
  (void)DeviceName;
  (void)BEACON_UUID;
  (void)ManufacturerId;
  startBruceyAdvertisement();
}
