#include "subghz.h"
#include "menu/subghz.h"
#include "Explorer.h"
#include "interface/interface.h"
#include "display.h"
#include <SD.h>
#include <SPI.h>
#include <RCSwitch.h>
#include <math.h>

// CC1101
#define DEFAULT_RF_FREQUENCY 433.92 // MHz
float frequency = DEFAULT_RF_FREQUENCY;
const float frequencies[] = {315.0, 433.92, 868.0, 915.0};
const int numFrequencies = sizeof(frequencies) / sizeof(frequencies[0]);
int freqIndex = 1; // Default 433.92 MHz

// RCSwitch
RCSwitch rcswitch = RCSwitch();

#define MAX_DATA_LOG 512

byte menuIndex = 0;
bool validKeyReceived = false;
bool readRAW = true;
bool autoSave = false;
int signals = 0;
uint64_t lastSavedKey = 0;
tpKeyData keyData1;
bool isJamming = false;

// Bruteforce state
const char* bruteTypes[] = {"Came", "Nice", "Ansonic", "Holtek", "Chamberlain"};
const int BRUTE_TYPE_COUNT = 5;
const float bruteFreqOptions[] = {315.0, 433.92, 868.0, 915.0};
const char* bruteFreqLabels[] = {"315.00MHz", "433.92MHz", "868.00MHz", "915.00MHz"};
const int BRUTE_FREQ_COUNT = 4;
const int bruteBits = 12;
int bruteTypeIndex = 0;
int bruteFreqIndex = 1;
int bruteConfigSelection = 0;
uint16_t bruteProgress = 0;
const uint16_t bruteTotal = 4096;
unsigned long bruteLastStep = 0;
bool bruteRunning = false;
bool bruteRfActive = false;
int bruteTxPin = CC1101_GDO0;

const int cameZero[] = {-320, 640};
const int cameOne[] = {-640, 320};
const int camePilot[] = {-11520, 320};
const BruteProtocol protoCame = {cameZero, 2, cameOne, 2, camePilot, 2, nullptr, 0};

const int niceZero[] = {-700, 1400};
const int niceOne[] = {-1400, 700};
const int nicePilot[] = {-25200, 700};
const BruteProtocol protoNice = {niceZero, 2, niceOne, 2, nicePilot, 2, nullptr, 0};

const int ansonicZero[] = {-1111, 555};
const int ansonicOne[] = {-555, 1111};
const int ansonicPilot[] = {-19425, 555};
const BruteProtocol protoAnsonic = {ansonicZero, 2, ansonicOne, 2, ansonicPilot, 2, nullptr, 0};

const int holtekZero[] = {-870, 430};
const int holtekOne[] = {-430, 870};
const int holtekPilot[] = {-15480, 430};
const BruteProtocol protoHoltek = {holtekZero, 2, holtekOne, 2, holtekPilot, 2, nullptr, 0};

const int chamberZero[] = {-870, 430};
const int chamberOne[] = {-430, 870};
const int chamberStop[] = {-3000, 1000};
const BruteProtocol protoChamber = {chamberZero, 2, chamberOne, 2, nullptr, 0, chamberStop, 2};
const BruteProtocol* currentBruteProto = nullptr;

#define MAX_FILES 50
static const char* subExts[] = {".sub"};
ExplorerEntry subFileList[MAX_FILES];
ExplorerState subExplorer;
ExplorerConfig subExplorerCfg = {"/subghz", subExts, 1, true, false, true, true};
int nextSignalIndex = 1;
bool nextSignalIndexReady = false;

#define CC1101_SPI_MODULE 1

struct BruceConfig {
  int rfModule = CC1101_SPI_MODULE;
  int rfTx = CC1101_GDO0;
} bruceConfig;

struct BruceConfigPins {
  struct {
    int io0 = CC1101_GDO0;
  } CC1101_bus;
} bruceConfigPins;

extern byte getSubGHzCC1101GDO0Pin();
extern byte getSubGHzCC1101CSPin();

static byte cc1101GDO0Pin = CC1101_GDO0;
static byte cc1101CSPin = CC1101_CS;

const float analyzerFreqs[] = {
  300.0, 302.75, 303.0, 303.87, 303.90, 304.25,
  307.0, 307.50, 307.80, 309.0, 310.0,
  312.0, 312.1, 312.2, 313.0, 313.85, 314.0, 314.35, 314.98, 315.0,
  318.0, 320.0, 320.15,
  330.0, 345.0, 348.0, 350.0,
  387.0, 390.0,
  418.0,
  430.0, 430.5, 431.0, 431.5,
  433.22, 433.42, 433.65, 433.88, 433.92,
  434.07, 434.17, 434.19, 434.39, 434.42, 434.62, 434.77,
  438.90, 440.17,
  462.75, 464.0, 467.75,
  779.0,
  868.35, 868.4, 868.46, 868.80, 868.95,
  906.4
};
const int ANALYZER_FREQ_COUNT = sizeof(analyzerFreqs) / sizeof(analyzerFreqs[0]);
const float ANALYZER_RSSI_LOW = -97.0f;
const float ANALYZER_RSSI_HIGH = -30.0f;
const float ANALYZER_RSSI_MUL = 2.3f;
const float ANALYZER_DEFAULT_TRIG = -75.0f;
const uint8_t ANALYZER_HIST_CNT = 4;
const int ANALYZER_TRIG_STEP = 5;
const uint16_t ANALYZER_STEP_DELAY_US = 3200;
const float ANALYZER_RSSI_GRAPH_SCALE = 2.0f;
const float ANALYZER_LOCK_MARGIN_DB = 6.0f;

bool analyzerIsNoiseFreq(uint32_t freqHz) {
  return
    (freqHz >= 310500000UL && freqHz <= 312300000UL) ||
    (freqHz >= 467500000UL && freqHz <= 468200000UL);
}

struct AnalyzerScanData {
  float rough_rssi = -127.0f;
  uint32_t rough_freq = 0;
  float fine_rssi = -127.0f;
  uint32_t fine_freq = 0;
};

struct AnalyzerState {
  uint32_t curr_freq = 0;
  uint32_t saved_freq = 0;
  float rssi_now = 0.0f;
  uint32_t hist_freq[ANALYZER_HIST_CNT] = {0};
  uint8_t hist_count[ANALYZER_HIST_CNT] = {0};
  bool has_signal = false;
  float last_rssi = 0.0f;
  float threshold = ANALYZER_DEFAULT_TRIG;
};

AnalyzerScanData analyzerScanResult;
AnalyzerState analyzerState;
float analyzerFilterVal = 0.0f;
float analyzerTrigLevel = ANALYZER_DEFAULT_TRIG;
uint8_t analyzerHoldCount = 0;
bool analyzerLocked = false;
float analyzerDetectedFrequency = 0.0f;
unsigned long analyzerLastDraw = 0;
bool analyzerExitRequested = false;
const float RAW_REC_DEFAULT_RSSI = -90.0f; // RAW FILTER
const float RAW_REC_MIN_RSSI = -90.0f;
const float RAW_REC_MAX_RSSI = -45.0f;
const float RAW_REC_RSSI_STEP = 5.0f;
const unsigned long RAW_REC_FRAME_GAP_US = 7000;
const int RAW_REC_MIN_EDGES = 20;
const int RAW_REC_MAX_EDGES = 900;



bool rawRecorderRunning = false;
bool rawRecorderStopped = false;
bool rawRecorderIgnoreOkRelease = false;
bool rawRecorderIgnoreBackRelease = false;
bool transmitIgnoreOkRelease = false;
bool transmitIgnoreBackRelease = false;
bool rawPlaybackActive = false;
bool rawPlaybackStopRequestedFlag = false;
bool rawPlaybackOkWasPressed = false;
bool rawPlaybackBackWasPressed = false;
unsigned long rawPlaybackBackPressedAt = 0;
bool rawPlaybackIgnoreOkRelease = false;
bool rawPlaybackIgnoreBackRelease = false;
float rawPlaybackShownPct = 0.0f;
float rawPlaybackTargetPct = 0.0f;
unsigned long rawPlaybackStartMs = 0;
unsigned long rawPlaybackLastDrawMs = 0;
TaskHandle_t rawPlaybackTaskHandle = nullptr;
float rawRecorderRssiThreshold = RAW_REC_DEFAULT_RSSI;
float rawRecorderLastRssi = -127.0f;
uint16_t rawRecorderSavedCount = 0;
unsigned long rawRecorderLastDraw = 0;
String rawRecorderLastFile = "";
String rawRecorderSessionFile = "";
String rawRecorderStoppedFile = "";
uint8_t rawRecorderSpectrumVals[52];
int rawRecorderEdges[RAW_REC_MAX_EDGES];
int rawRecorderEdgeCount = 0;
int rawRecorderPrevLevel = LOW;
unsigned long rawRecorderPrevEdgeUs = 0;
unsigned long rawRecorderLastEdgeUs = 0;

bool setupCC1101();
void configureCC1101();
void restoreReceiveMode();
void read_rcswitch(tpKeyData* kd);
void read_raw(tpKeyData* kd);
void OLED_printWaitingSignal();
void OLED_printRawRecorder();
void drawRawRecorderButton();
void drawRawRecorderSpectrum(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
void resetRawRecorderSpectrum();
void stepRawRecorderRssiThreshold();
static bool subGHzFileNameNeedsScroll(const String& fileName);
static void subGHzPrintFileName(DisplayType& display, const String& fileName, int16_t x, int16_t y);
void OLED_printKey(tpKeyData* kd, String fileName = "", bool isSending = false);
void OLED_printError(String st, bool err = true);
void OLED_printCC1101InitError();
void waitBackFromCC1101InitError();
bool saveKeyToSD(tpKeyData* kd);
String allocateNextSignalFileName();
bool startRawRecorderSession();
void stopRawRecorderSession(bool flushPending = true, bool discardFile = false);
bool saveRawFrameToSession(const String& rawData, float rssi);
void flushRawRecorderFrame();
void handleRawRecorderCapture();
bool loadKeyFromSD(String fileName, tpKeyData* kd);
void syncNextSignalIndexFromFiles();
void sendSynthKey(tpKeyData* kd);
bool playRawRecorderFile(const String& fileName);
void drawRawPlaybackWave(float phase, uint8_t progressPct);
void stepFrequency(int step);
void RCSwitch_send(uint64_t data, unsigned int bits, int pulse, int protocol, int repeat);
void RCSwitch_RAW_send(int *ptrtransmittimings);
void analyzerInit();
uint32_t analyzerSmoothAvg(uint32_t newVal);
uint32_t analyzerNearestFreq(uint32_t input);
void analyzerAddHistory(uint32_t freq);
void analyzerSaveFreq();
bool analyzerHandleInput();
void analyzerDoScan();
void analyzerDrawGraph(uint8_t x, uint8_t y);
void OLED_printAnalyzer();
void OLED_printJammer();
void startJamming();
void stopJamming();
String getTypeName(emKeys tp);
bool initRfModule(String mode, float freq);
void deinitRfModule();
void resetButtonStates();
void OLED_printBruteIntro();
void OLED_printBruteConfig(int previousSelection = -1);
void OLED_printBruteProgress(uint16_t progress, uint16_t total);
bool bruteInitTx();
void bruteStopTx();
void bruteSendCode(uint16_t code);

static byte bruceyDirectCC1101Version() {
  pinMode(CC1101_CS, OUTPUT);
  digitalWrite(CC1101_CS, HIGH);
  pinMode(NRF24_CSN, OUTPUT);
  digitalWrite(NRF24_CSN, HIGH);
  pinMode(NRF24_CE, OUTPUT);
  digitalWrite(NRF24_CE, LOW);

  SPI.end();
  delay(2);
  SPI.begin(CC1101_SCK, CC1101_MISO, CC1101_MOSI, CC1101_CS);
  delay(2);

  SPI.beginTransaction(SPISettings(125000, MSBFIRST, SPI_MODE0));
  digitalWrite(CC1101_CS, LOW);
  uint32_t start = micros();
  while (digitalRead(CC1101_MISO) == HIGH && (micros() - start) < 5000UL) {
    delayMicroseconds(2);
  }
  SPI.transfer(0x31 | 0xC0);
  byte v = SPI.transfer(0x00);
  digitalWrite(CC1101_CS, HIGH);
  SPI.endTransaction();
  return v;
}

static bool cc1101IsConnected() {
  byte version = ELECHOUSE_cc1101.SpiReadStatus(CC1101_VERSION);
  return version != 0x00 && version != 0xFF;
}

static bool cc1101PinsReady = false;
static bool cc1101Initialized = false;

static bool rcSwitchReceiveEnabled = false;

static void syncCC1101PinsFromGPIOConfig() {
  byte newGDO0Pin = getSubGHzCC1101GDO0Pin();
  byte newCSPin = getSubGHzCC1101CSPin();
  if (cc1101GDO0Pin == newGDO0Pin && cc1101CSPin == newCSPin) return;

  cc1101GDO0Pin = newGDO0Pin;
  cc1101CSPin = newCSPin;
  bruceConfig.rfTx = cc1101GDO0Pin;
  bruceConfigPins.CC1101_bus.io0 = cc1101GDO0Pin;
  cc1101PinsReady = false;
  cc1101Initialized = false;
}

static void prepareCC1101Pins() {
  syncCC1101PinsFromGPIOConfig();
  if (cc1101PinsReady) return;
  pinMode(cc1101CSPin, OUTPUT);
  digitalWrite(cc1101CSPin, HIGH);
  SD.end();

  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);

  pinMode(NRF24_CSN, OUTPUT);
  digitalWrite(NRF24_CSN, HIGH);

  pinMode(NRF24_CE, OUTPUT);
  digitalWrite(NRF24_CE, LOW);

  // Re-create the exact SPI routing proven by the standalone V7 diagnostic.
  SPI.end();
  delay(2);
  SPI.begin(CC1101_SCK, CC1101_MISO, CC1101_MOSI, cc1101CSPin);
  delay(5);

  // Direct read sanity check before the CC1101 library takes over.
  SPI.beginTransaction(SPISettings(125000, MSBFIRST, SPI_MODE0));
  digitalWrite(cc1101CSPin, LOW);
  uint32_t bruceyWait = micros();
  while (digitalRead(CC1101_MISO) == HIGH && (micros() - bruceyWait) < 5000UL) {
    delayMicroseconds(2);
  }
  SPI.transfer(0x31 | 0xC0);
  uint8_t bruceyCcVer = SPI.transfer(0x00);
  digitalWrite(cc1101CSPin, HIGH);
  SPI.endTransaction();
  Serial.printf("[BRUCEY V11] CC1101 direct VER=%02X\n", bruceyCcVer);

  ELECHOUSE_cc1101.setSpiPin(CC1101_SCK, CC1101_MISO, CC1101_MOSI, cc1101CSPin);
  ELECHOUSE_cc1101.setGDO0(cc1101GDO0Pin);
  cc1101PinsReady = true;
}

static bool ensureCC1101Initialized() {
  prepareCC1101Pins();

  // First prove the physical SPI path with the exact transaction that worked
  // in the standalone diagnostics.
  byte before = bruceyDirectCC1101Version();
  Serial.printf("[BRUCEY V11] CC1101 direct before Init VER=%02X\n", before);
  if (before != 0x14) {
    cc1101Initialized = false;
    return false;
  }

  // Let the upstream library configure the chip.
  ELECHOUSE_cc1101.Init();
  delay(5);

  // The library's own connection check was a false negative on this S3 port,
  // so verify again with the known-good direct transaction.
  byte after = bruceyDirectCC1101Version();
  Serial.printf("[BRUCEY V11] CC1101 direct after Init VER=%02X\n", after);

  cc1101Initialized = (after == 0x14);
  return cc1101Initialized;
}

bool initRfModule(String mode, float freq) {
  if (!ensureCC1101Initialized()) {
    return false;
  }
  ELECHOUSE_cc1101.setMHZ(freq);
  ELECHOUSE_cc1101.setModulation(2);
  if (mode == "tx" || mode == "TX") {
    ELECHOUSE_cc1101.setSyncMode(0);
    ELECHOUSE_cc1101.setCrc(0);
    ELECHOUSE_cc1101.setPktFormat(3);
    ELECHOUSE_cc1101.SetTx();
    pinMode(cc1101GDO0Pin, OUTPUT);
    digitalWrite(cc1101GDO0Pin, LOW);
  } else {
    ELECHOUSE_cc1101.setPktFormat(0);
    ELECHOUSE_cc1101.SetRx();
  }
  ELECHOUSE_cc1101.SpiStrobe(0x33);
  delayMicroseconds(100);
  return true;
}

void deinitRfModule() {
  ELECHOUSE_cc1101.SpiStrobe(0x36);
  ELECHOUSE_cc1101.SetRx();
  pinMode(cc1101GDO0Pin, OUTPUT);
  digitalWrite(cc1101GDO0Pin, LOW);
}

static void enableRcSwitchReceive() {
  if (rcSwitchReceiveEnabled) {
    return;
  }

  pinMode(cc1101GDO0Pin, INPUT);
  rcswitch.enableReceive(cc1101GDO0Pin);
  rcSwitchReceiveEnabled = true;

  Serial.printf(
    "[RCSwitch] RX enabled on GPIO %u\n",
    cc1101GDO0Pin
  );
}

static void disableRcSwitchReceive() {
  if (!rcSwitchReceiveEnabled) {
    return;
  }

  rcswitch.disableReceive();
  rcSwitchReceiveEnabled = false;

  Serial.println(F("[RCSwitch] RX disabled"));
}

void runSubGHz() {
  if (!setupCC1101()) {
    Serial.println(F("Failed to initialize CC1101"));
    OLED_printCC1101InitError();
    waitBackFromCC1101InitError();
    resetButtonStates();
    return;
  }
  enableRcSwitchReceive();
  emMenuState menuState = menuMain;
  menuIndex = 0;
  OLED_printSubGHzMenu(display, menuIndex);

  while (true) {
    static MenuButtonState upHeld;
    static MenuButtonState downHeld;
    buttonUp.tick();
    buttonDown.tick();
    buttonOK.tick();
    buttonBack.tick();

    if (menuState == menuMain) {
      byte lastMenuIndex = SUBGHZ_MENU_ITEM_COUNT - 1;
      const unsigned long repeatDelayMs = getMenuSubmenuRepeatDelay(submenu == 1);
      if (isMenuButtonPress(BUTTON_UP, upHeld, repeatDelayMs)) {
        byte previousIndex = menuIndex;
        menuIndex = (menuIndex == 0) ? lastMenuIndex : menuIndex - 1;
        OLED_printSubGHzMenu(display, menuIndex, previousIndex);
      }
      if (isMenuButtonPress(BUTTON_DOWN, downHeld, repeatDelayMs)) {
        byte previousIndex = menuIndex;
        menuIndex = (menuIndex == lastMenuIndex) ? 0 : menuIndex + 1;
        OLED_printSubGHzMenu(display, menuIndex, previousIndex);
      }
      if (buttonOK.isClick()) {
        if (menuIndex == 0) {
          if (!ensureSDReadyInteractive(true)) {
            OLED_printSubGHzMenu(display, menuIndex);
            continue;
          }
          menuState = menuReceive;
          setupCC1101();
          disableRcSwitchReceive();
          enableRcSwitchReceive();
          validKeyReceived = false;
          signals = 0;
          memset(&keyData1, 0, sizeof(tpKeyData));
          lastSavedKey = 0;
          rcswitch.resetAvailable();
          resetButtonStates();
          OLED_printWaitingSignal();
        } else if (menuIndex == 1) {
          if (!ensureSDReadyInteractive(true)) {
            OLED_printSubGHzMenu(display, menuIndex);
            continue;
          }
          menuState = menuRawRecorder;
          setupCC1101();
          rawRecorderRunning = false;
          rawRecorderStopped = false;
          rawRecorderIgnoreOkRelease = true;
          rawRecorderIgnoreBackRelease = false;
          rawRecorderSavedCount = 0;
          rawRecorderLastRssi = -127.0f;
          rawRecorderLastFile = "";
          rawRecorderSessionFile = "";
          rawRecorderStoppedFile = "";
          rawRecorderEdgeCount = 0;
          rawRecorderPrevLevel = digitalRead(cc1101GDO0Pin);
          rawRecorderPrevEdgeUs = micros();
          rawRecorderLastEdgeUs = rawRecorderPrevEdgeUs;
          rawRecorderLastDraw = 0;
          resetRawRecorderSpectrum();
          resetButtonStates();
          OLED_printRawRecorder();
        } else if (menuIndex == 2) {
          if (!ensureSDReadyInteractive(true)) {
            OLED_printSubGHzMenu(display, menuIndex);
            continue;
          }
          menuState = menuTransmit;
          transmitIgnoreOkRelease = false;
          transmitIgnoreBackRelease = false;
          ExplorerInit(subExplorer, subFileList, MAX_FILES, subExplorerCfg);
          ExplorerLoad(subExplorer, subExplorerCfg);
          syncNextSignalIndexFromFiles();
          ExplorerDraw(subExplorer, display);
          resetButtonStates();
        } else if (menuIndex == 3) {
          menuState = menuAnalyzer;
          setupCC1101();
          disableRcSwitchReceive();
          analyzerInit();
          analyzerExitRequested = false;
          resetButtonStates();
          OLED_printAnalyzer();
        } else if (menuIndex == 4) {
          menuState = menuJammer;
          isJamming = false;
          resetButtonStates();
          OLED_printJammer();
        } else if (menuIndex == 5) {
          menuState = menuBruteforce;
          bruteRunning = false;
          resetButtonStates();
          OLED_printBruteIntro();
        }
      }
      if (buttonBack.isClick()) {
        break;
      }
    } else if (menuState == menuReceive) {
      if (buttonUp.isClick()) {
        stepFrequency(1);
        keyData1.frequency = frequency;
        setupCC1101();
        OLED_printWaitingSignal();
      }
      if (buttonDown.isClick()) {
        stepFrequency(-1);
        keyData1.frequency = frequency;
        setupCC1101();
        OLED_printWaitingSignal();
      }
      if (buttonOK.isHolded() && validKeyReceived) {
        if (saveKeyToSD(&keyData1)) {
          display.clearDisplay();
          display.drawBitmap(16, 6, image_DolphinSaved_bits, 92, 58, SH110X_WHITE);
          display.setTextColor(SH110X_WHITE);
          display.setCursor(6, 16);
          display.print("Saved");
          display.display();
          Serial.println(F("Key saved"));
          delay(1000);
          validKeyReceived = false;
          signals = 0;
          memset(&keyData1, 0, sizeof(tpKeyData));
          lastSavedKey = 0;
          rcswitch.resetAvailable();
        } else {
          ExplorerShowSDError(display);
          Serial.println(F("Failed to save key to SD"));
        }
        OLED_printWaitingSignal();
      }
      if (buttonBack.isClick()) {
        menuState = menuMain;
        resetButtonStates();
        OLED_printSubGHzMenu(display, menuIndex);
      }
      if (rcswitch.available()) {
        Serial.println(F(" Signal:"));
        if (!readRAW) read_rcswitch(&keyData1);
        else read_raw(&keyData1);
        if (validKeyReceived && autoSave && (lastSavedKey != keyData1.keyID[0] || keyData1.keyID[0] == 0)) {
          if (saveKeyToSD(&keyData1)) {
            lastSavedKey = keyData1.keyID[0];
            validKeyReceived = false;
            signals = 0;
            memset(&keyData1, 0, sizeof(tpKeyData));
            rcswitch.resetAvailable();
          } else {
            Serial.println(F("Auto-save failed"));
          }
        }
      }
    } else if (menuState == menuRawRecorder) {
      if (rawRecorderIgnoreOkRelease) {
        if (digitalRead(BUTTON_OK) == LOW) {
          (void)buttonOK.isClick();
        } else {
          rawRecorderIgnoreOkRelease = false;
          buttonOK.resetStates();
        }
      }
      if (rawRecorderIgnoreBackRelease) {
        if (digitalRead(BUTTON_BACK) == LOW) {
          (void)buttonBack.isClick();
        } else {
          rawRecorderIgnoreBackRelease = false;
          buttonBack.resetStates();
        }
      }

      bool upClick = buttonUp.isClick();
      bool downClick = buttonDown.isClick();
      bool okClick = !rawRecorderIgnoreOkRelease && buttonOK.isClick();
      bool backClick = !rawRecorderIgnoreBackRelease && buttonBack.isClick();

      if (rawRecorderStopped) {
        if (downClick) {
          if (rawRecorderStoppedFile.length() > 0 && SD.exists(rawRecorderStoppedFile)) {
            SD.remove(rawRecorderStoppedFile);
          }
          rawRecorderStopped = false;
          rawRecorderStoppedFile = "";
          rawRecorderLastFile = "";
          rawRecorderSavedCount = 0;
          rawRecorderEdgeCount = 0;
          resetRawRecorderSpectrum();
          OLED_printRawRecorder();
        } else if (upClick) {
          display.clearDisplay();
          display.drawBitmap(16, 6, image_DolphinSaved_bits, 92, 58, SH110X_WHITE);
          display.setTextColor(SH110X_WHITE);
          display.setCursor(6, 16);
          display.print("Saved");
          display.display();
          delay(1000);
          rawRecorderStopped = false;
          rawRecorderStoppedFile = "";
          rawRecorderLastFile = "";
          rawRecorderSavedCount = 0;
          rawRecorderEdgeCount = 0;
          resetRawRecorderSpectrum();
          OLED_printRawRecorder();
        } else if (backClick) {
          menuState = menuMain;
          resetButtonStates();
          OLED_printSubGHzMenu(display, menuIndex);
        } else if (okClick) {
          playRawRecorderFile(rawRecorderStoppedFile);
          OLED_printRawRecorder();
          resetButtonStates();
        }
        continue;
      }

      if (!rawRecorderRunning && upClick) {
        stepRawRecorderRssiThreshold();
        OLED_printRawRecorder();
      }
      if (!rawRecorderRunning && downClick) {
        stepFrequency(1);
        setupCC1101();
        rawRecorderPrevLevel = digitalRead(cc1101GDO0Pin);
        rawRecorderPrevEdgeUs = micros();
        rawRecorderLastEdgeUs = rawRecorderPrevEdgeUs;
        rawRecorderEdgeCount = 0;
        resetRawRecorderSpectrum();
        OLED_printRawRecorder();
      }
      if (backClick) {
        if (rawRecorderRunning) {
          stopRawRecorderSession(true, false);
          rawRecorderRunning = false;
          rawRecorderLastDraw = 0;
          OLED_printRawRecorder();
        } else {
          menuState = menuMain;
          resetButtonStates();
          OLED_printSubGHzMenu(display, menuIndex);
        }
      } else if (okClick) {
        if (!rawRecorderRunning) {
          if (startRawRecorderSession()) {
            rawRecorderRunning = true;
            rawRecorderStopped = false;
            resetRawRecorderSpectrum();
          } else {
            ExplorerShowSDError(display, 700);
          }
        } else {
          String stoppedFile = rawRecorderSessionFile;
          stopRawRecorderSession(true, false);
          rawRecorderRunning = false;
          rawRecorderStopped = true;
          rawRecorderStoppedFile = stoppedFile;
        }
        rawRecorderLastDraw = 0;
        OLED_printRawRecorder();
      } else if (rawRecorderRunning) {
        handleRawRecorderCapture();
        if (millis() - rawRecorderLastDraw >= 120) {
          OLED_printRawRecorder();
          rawRecorderLastDraw = millis();
        }
      }
    } else if (menuState == menuTransmit && subExplorer.inExplorer) {
      ExplorerAction action = ExplorerHandle(
        subExplorer,
        subExplorerCfg,
        display,
        buttonUp.isClick(),
        buttonDown.isClick(),
        buttonOK.isClick(),
        buttonBack.isClick(),
        buttonBack.isHolded()
      );
      if (action == EXPLORER_SELECT_FILE) {
        subExplorer.inExplorer = false;
        resetButtonStates();
        if (loadKeyFromSD(subExplorer.selectedFile, &keyData1)) {
          OLED_printKey(&keyData1, subExplorer.selectedFile);
        } else {
          ExplorerShowSDError(display);
          subExplorer.inExplorer = true;
          ExplorerDraw(subExplorer, display);
        }
      } else if (action == EXPLORER_EXIT) {
        menuState = menuMain;
        subExplorer.inExplorer = false;
        subExplorer.selectedFile = "";
        resetButtonStates();
        OLED_printSubGHzMenu(display, menuIndex);
      }
    } else if (menuState == menuTransmit && !subExplorer.inExplorer) {
      if (transmitIgnoreOkRelease) {
        if (digitalRead(BUTTON_OK) == LOW) {
          (void)buttonOK.isClick();
        } else {
          transmitIgnoreOkRelease = false;
          buttonOK.resetStates();
        }
      }
      if (transmitIgnoreBackRelease) {
        if (digitalRead(BUTTON_BACK) == LOW) {
          (void)buttonBack.isClick();
        } else {
          transmitIgnoreBackRelease = false;
          buttonBack.resetStates();
        }
      }

      bool okClick = !transmitIgnoreOkRelease && buttonOK.isClick();
      bool backClick = !transmitIgnoreBackRelease && buttonBack.isClick();
      static unsigned long lastKeyMarqueeDrawAt = 0;

      if (okClick) {
        sendSynthKey(&keyData1);
        restoreReceiveMode();
        lastKeyMarqueeDrawAt = millis();
      }
      if (backClick) {
        subExplorer.inExplorer = true;
        resetButtonStates();
        ExplorerDraw(subExplorer, display);
      }
      if (!okClick && !backClick && subGHzFileNameNeedsScroll(subExplorer.selectedFile) &&
          millis() - lastKeyMarqueeDrawAt >= 200) {
        lastKeyMarqueeDrawAt = millis();
        OLED_printKey(&keyData1, subExplorer.selectedFile);
      }
    } else if (menuState == menuBruteforce) {
      if (buttonOK.isHolded()) {
        bruteConfigSelection = 0;
        menuState = menuBruteConfig;
        OLED_printBruteConfig();
      } else if (buttonOK.isClick()) {
        bruteProgress = 0;
        freqIndex = bruteFreqIndex;
        frequency = bruteFreqOptions[bruteFreqIndex];
        bruteLastStep = millis();
        if (bruteInitTx()) {
          bruteRunning = true;
          menuState = menuBruteRun;
          OLED_printBruteProgress(bruteProgress, bruteTotal);
        } else {
          bruteRunning = false;
          OLED_printError(F("Brute init fail"), true);
          delay(800);
          OLED_printBruteIntro();
        }
      }
      if (buttonBack.isClick()) {
        menuState = menuMain;
        bruteRunning = false;
        resetButtonStates();
        OLED_printSubGHzMenu(display, menuIndex);
      }
    } else if (menuState == menuBruteConfig) {
      if (buttonUp.isClick()) {
        int previousSelection = bruteConfigSelection;
        bruteConfigSelection = (bruteConfigSelection == 0) ? 1 : bruteConfigSelection - 1;
        OLED_printBruteConfig(previousSelection);
      }
      if (buttonDown.isClick()) {
        int previousSelection = bruteConfigSelection;
        bruteConfigSelection = (bruteConfigSelection + 1) % 2;
        OLED_printBruteConfig(previousSelection);
      }
      if (buttonOK.isClick()) {
        if (bruteConfigSelection == 0) {
          bruteTypeIndex = (bruteTypeIndex + 1) % BRUTE_TYPE_COUNT;
        } else {
          bruteFreqIndex = (bruteFreqIndex + 1) % BRUTE_FREQ_COUNT;
        }
        OLED_printBruteConfig();
      }
      if (buttonBack.isClick()) {
        freqIndex = bruteFreqIndex;
        frequency = bruteFreqOptions[bruteFreqIndex];
        menuState = menuBruteforce;
        resetButtonStates();
        OLED_printBruteIntro();
      }
    } else if (menuState == menuBruteRun) {
      if (buttonBack.isClick()) {
        bruteRunning = false;
        bruteStopTx();
        menuState = menuMain;
        resetButtonStates();
        OLED_printSubGHzMenu(display, menuIndex);
      }
      if (buttonOK.isClick()) {
        bruteRunning = false;
        bruteStopTx();
        menuState = menuBruteforce;
        resetButtonStates();
        OLED_printBruteIntro();
      }
      if (bruteRunning && millis() - bruteLastStep >= 15) {
        bruteLastStep = millis();
        if (bruteProgress < bruteTotal) {
          bruteSendCode(bruteProgress);
          bruteProgress++;
          if (bruteProgress % 8 == 0 || bruteProgress == bruteTotal) {
            OLED_printBruteProgress(bruteProgress, bruteTotal);
          }
        }
        if (bruteProgress >= bruteTotal) {
          bruteRunning = false;
          bruteStopTx();
          menuState = menuBruteforce;
          resetButtonStates();
          OLED_printBruteIntro();
        }
      }
    } else if (menuState == menuAnalyzer) {
      if (analyzerExitRequested) {
        analyzerExitRequested = false;
        menuState = menuMain;

        disableRcSwitchReceive();

        if (analyzerDetectedFrequency >= 280.0f && analyzerDetectedFrequency <= 928.0f) {
          frequency = analyzerDetectedFrequency;
          keyData1.frequency = frequency;
          Serial.printf("[SubGHz] Analyzer -> Read tuned to %.3f MHz\n", frequency);
        }

        restoreReceiveMode();

        resetButtonStates();
        OLED_printSubGHzMenu(display, menuIndex);
      } else {
        if (!analyzerHandleInput()) {
          continue;
        }

        analyzerDoScan();

        if (analyzerExitRequested) {
          continue;
        }

        if (millis() - analyzerLastDraw >= 50) {
          OLED_printAnalyzer();
          analyzerLastDraw = millis();
        }
      }
    } else if (menuState == menuJammer) {
      if (buttonUp.isClick()) {
        stepFrequency(1);
        if (isJamming) {
          stopJamming();
          startJamming();
        }
        OLED_printJammer();
      }
      if (buttonDown.isClick()) {
        stepFrequency(-1);
        if (isJamming) {
          stopJamming();
          startJamming();
        }
        OLED_printJammer();
      }
      if (buttonOK.isClick()) {
        if (!isJamming) {
          startJamming();
          isJamming = true;
        } else {
          stopJamming();
          isJamming = false;
        }
        OLED_printJammer();
      }
      if (buttonBack.isClick()) {
        if (isJamming) {
          stopJamming();
          isJamming = false;
        }
        menuState = menuMain;
        restoreReceiveMode();
        resetButtonStates();
        OLED_printSubGHzMenu(display, menuIndex);
      }
    }
  }

  if (isJamming) {
    stopJamming();
    isJamming = false;
  }
  if (bruteRfActive) {
    bruteStopTx();
  }
  if (rawRecorderRunning || rawRecorderSessionFile.length() > 0) {
    stopRawRecorderSession(false, true);
    rawRecorderRunning = false;
  }
  restoreReceiveMode();
}

void resetButtonStates() {
  buttonUp.resetStates();
  buttonDown.resetStates();
  buttonOK.resetStates();
  buttonBack.resetStates();
}

bool setupCC1101() {
  if (!ensureCC1101Initialized()) {
    return false;
  }
  ELECHOUSE_cc1101.SpiStrobe(0x36);
  delayMicroseconds(100);
  configureCC1101();
  return true;
}

void configureCC1101() {
  ELECHOUSE_cc1101.setModulation(2);
  ELECHOUSE_cc1101.setMHZ(frequency);
  ELECHOUSE_cc1101.setRxBW(270.0);
  ELECHOUSE_cc1101.setDeviation(0);
  ELECHOUSE_cc1101.setPA(12);
  ELECHOUSE_cc1101.SpiStrobe(0x36);
  delayMicroseconds(100);
  ELECHOUSE_cc1101.SetRx();
}

void restoreReceiveMode() {
  if (!ensureCC1101Initialized()) {
    return;
  }

  configureCC1101();

  disableRcSwitchReceive();
  enableRcSwitchReceive();
  rcswitch.resetAvailable();
}

void read_rcswitch(tpKeyData* kd) {
  uint32_t decoded = rcswitch.getReceivedValue();
  if (decoded) {
    signals++;
    kd->frequency = frequency;
    int numBytes = (kd->bitLength + 7) / 8;
    if (numBytes > 4) numBytes = 4;
    for (int i = 0; i < 8; i++) {
      kd->keyID[i] = (i < 8 - numBytes) ? 0 : (decoded >> ((numBytes - 1 - (i - (8 - numBytes))) * 8)) & 0xFF;
    }
    kd->type = (rcswitch.getReceivedProtocol() == 1 && rcswitch.getReceivedBitlength() == 24) ? kPrinceton : kRcSwitch;
    if (rcswitch.getReceivedBitlength() <= 40 && rcswitch.getReceivedProtocol() == 11) {
      kd->type = kCAME;
    }
    kd->te = rcswitch.getReceivedDelay();
    kd->bitLength = rcswitch.getReceivedBitlength();
    kd->codeLenth = kd->bitLength;
    strncpy(kd->preset, "0", sizeof(kd->preset) - 1);
    kd->preset[sizeof(kd->preset) - 1] = '\0';
    kd->rawData[0] = '\0';
    unsigned int* raw = rcswitch.getReceivedRawdata();
    String rawStr = "";
    for (int i = 0; i < kd->bitLength * 2 && i < 15; i++) {
      if (i > 0) rawStr += " ";
      int sign = (i % 2 == 0) ? 1 : -1;
      rawStr += String(sign * (int)raw[i]);
    }
    strncpy(kd->rawData, rawStr.c_str(), sizeof(kd->rawData) - 1);
    kd->rawData[sizeof(kd->rawData) - 1] = '\0';
    validKeyReceived = true;
    OLED_printKey(kd, "", false);
  }
  rcswitch.resetAvailable();
}

void read_raw(tpKeyData* kd) {
  unsigned int* raw = rcswitch.getReceivedRawdata();
  uint32_t decoded = rcswitch.getReceivedValue();
  String data = "";
  int transitions = 0;
  for (transitions = 0; transitions < MAX_DATA_LOG && raw[transitions] != 0; transitions++) {
    if (transitions > 0) data += " ";
    int sign = (transitions % 2 == 0) ? 1 : -1;
    data += String(sign * (int)raw[transitions]);
  }
  if (transitions > 20) {
    signals++;
    kd->frequency = frequency;
    if (data.length() >= sizeof(kd->rawData)) {
      data = data.substring(0, sizeof(kd->rawData) - 1);
    }
    strncpy(kd->rawData, data.c_str(), sizeof(kd->rawData) - 1);
    kd->rawData[sizeof(kd->rawData) - 1] = '\0';
    kd->type = kUnknown;
    kd->te = 0;
    kd->bitLength = 0;
    strncpy(kd->preset, "0", sizeof(kd->preset) - 1);
    kd->preset[sizeof(kd->preset) - 1] = '\0';
    kd->codeLenth = transitions;
    if (decoded) {
      int numBytes = (rcswitch.getReceivedBitlength() + 7) / 8;
      if (numBytes > 4) numBytes = 4;
      for (int i = 0; i < 8; i++) {
        kd->keyID[i] = (i < 8 - numBytes) ? 0 : (decoded >> ((numBytes - 1 - (i - (8 - numBytes))) * 8)) & 0xFF;
      }
      kd->type = (rcswitch.getReceivedProtocol() == 1 && rcswitch.getReceivedBitlength() == 24) ? kPrinceton : kRcSwitch;
      if (rcswitch.getReceivedBitlength() <= 40 && rcswitch.getReceivedProtocol() == 11) {
        kd->type = kCAME;
      }
      kd->te = rcswitch.getReceivedDelay();
      kd->bitLength = rcswitch.getReceivedBitlength();
      kd->codeLenth = kd->bitLength;
      strncpy(kd->preset, "0", sizeof(kd->preset) - 1);
      kd->preset[sizeof(kd->preset) - 1] = '\0';
    } else {
      if (transitions >= 129 && transitions <= 137) kd->type = kStarLine;
      else if (transitions >= 133 && transitions <= 137) kd->type = kKeeLoq;
      else if (transitions >= 40 && transitions <= 60) kd->type = kCAME;
    }
    validKeyReceived = true;
    OLED_printKey(kd, "", false);
  }
  rcswitch.resetAvailable();
}

void OLED_printWaitingSignal() {
  display.clearDisplay();
  display.drawBitmap(0, 4, image_DolphinReceive_bits, 97, 61, SH110X_WHITE);
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setTextWrap(false);
  display.setCursor(65, 38);
  display.print("Waiting");
  display.setCursor(65, 47);
  display.print("signal...");
  display.setCursor(72, 13);
  display.print(String(frequency, 2) + "MHz");
  display.display();
}

void OLED_printRawRecorder() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setTextWrap(false);

  display.setCursor(5, 3);
  display.print(String(frequency, 2) + F("MHz"));
  display.drawRect(66, 2, 2, 9, 1);

  display.setCursor(76, 3);
  display.print(F("RSSI:"));
  display.print((int)rawRecorderRssiThreshold);

  display.drawRect(10, 13, 108, 37, SH110X_WHITE);
  if (rawRecorderRunning || rawRecorderStopped) {
    drawRawRecorderSpectrum(12, 15, 104, 33);
  }

  float filterPct = (rawRecorderRssiThreshold - RAW_REC_MIN_RSSI) / (RAW_REC_MAX_RSSI - RAW_REC_MIN_RSSI);
  if (filterPct < 0.0f) filterPct = 0.0f;
  if (filterPct > 1.0f) filterPct = 1.0f;
  uint8_t arrowY = 45 - (uint8_t)(filterPct * 16.0f + 0.5f);
  display.drawBitmap(120, arrowY, image_ArrowLeft_bits, 3, 5, SH110X_WHITE);
  drawRawRecorderButton();
  display.display();
}

void drawRawRecorderButton() {
  if (rawRecorderStopped) {
    display.fillRoundRect(1, 52, 41, 12, 2, SH110X_WHITE);
    display.fillRect(1, 54, 41, 10, SH110X_WHITE);
    display.fillRoundRect(44, 52, 41, 12, 2, SH110X_WHITE);
    display.fillRect(44, 54, 41, 10, SH110X_WHITE);
    display.fillRoundRect(87, 52, 40, 12, 2, SH110X_WHITE);
    display.fillRect(87, 54, 40, 10, SH110X_WHITE);

    display.setTextColor(SH110X_BLACK);
    display.setCursor(3, 55);
    display.print("Erase");
    display.drawBitmap(35, 58, image_ArrowDown_bits, 5, 3, SH110X_BLACK);

    display.setCursor(47, 55);
    display.print("Play");
    display.drawBitmap(73, 54, image_REC_bits, 9, 9, SH110X_BLACK);

    display.setCursor(92, 55);
    display.print("Save");
    display.drawBitmap(118, 57, image_ArrowUp_bits, 5, 3, SH110X_BLACK);
    display.setTextColor(SH110X_WHITE);
    return;
  }

  const char* label = rawRecorderRunning ? "Stop" : "REC";
  const uint8_t textW = strlen(label) * 6;
  const uint8_t iconW = 9;
  const uint8_t iconH = 9;
  const uint8_t gap = 3;
  const uint8_t contentW = textW + gap + iconW;
  const uint8_t padX = 5;
  const uint8_t x = (SCREEN_WIDTH - (contentW + padX * 2)) / 2;
  const uint8_t y = 52;
  const uint8_t w = contentW + padX * 2;
  const uint8_t h = 12;

  display.fillRoundRect(x, y, w, h, 2, SH110X_WHITE);
  display.fillRect(x, y + 2, w, h - 2, SH110X_WHITE);

  const uint8_t textX = x + padX;
  const uint8_t iconX = textX + textW + gap;
  display.setTextColor(SH110X_BLACK);
  display.setCursor(textX, y + ((strcmp(label, "REC") == 0) ? 3 : 2));
  display.print(label);
  display.drawBitmap(iconX, y + 2, image_REC_bits, iconW, iconH, SH110X_BLACK);
  display.setTextColor(SH110X_WHITE);
}

void drawRawRecorderSpectrum(uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
  const uint8_t barCount = min((uint8_t)sizeof(rawRecorderSpectrumVals), (uint8_t)(w / 2));

  if (rawRecorderRunning) {
    for (uint8_t i = 0; i < barCount - 1; i++) {
      rawRecorderSpectrumVals[i] = rawRecorderSpectrumVals[i + 1];
    }

    float rssi = ELECHOUSE_cc1101.getRssi();
    if (rssi < -100.0f) rssi = -100.0f;
    if (rssi > -30.0f) rssi = -30.0f;
    rawRecorderSpectrumVals[barCount - 1] = 1 + (uint8_t)(((rssi + 100.0f) * (h - 1)) / 70.0f);
  }

  for (uint8_t i = 0; i < barCount; i++) {
    uint8_t bar = rawRecorderSpectrumVals[i];
    if (bar > 0) {
      uint8_t px = x + i * 2;
      display.drawFastVLine(px, y + h - bar, bar, SH110X_WHITE);
      display.drawFastVLine(px + 1, y + h - bar, bar, SH110X_WHITE);
    }
  }
}

void resetRawRecorderSpectrum() {
  for (uint8_t i = 0; i < sizeof(rawRecorderSpectrumVals); i++) {
    rawRecorderSpectrumVals[i] = 0;
  }
}

void stepRawRecorderRssiThreshold() {
  rawRecorderRssiThreshold += RAW_REC_RSSI_STEP;
  if (rawRecorderRssiThreshold > RAW_REC_MAX_RSSI) {
    rawRecorderRssiThreshold = RAW_REC_MIN_RSSI;
  }
}

static bool subGHzFileNameNeedsScroll(const String& fileName) {
  return fileName.length() > 15;
}

static void subGHzPrintFileName(DisplayType& display, const String& fileName, int16_t x, int16_t y) {
  static String marqueeText = "";
  static unsigned long marqueeStartedAt = 0;

  const int visibleChars = 15;
  if (fileName.length() <= visibleChars) {
    marqueeText = "";
    marqueeStartedAt = 0;
    display.setCursor(x, y);
    display.print(fileName);
    return;
  }

  if (marqueeText != fileName) {
    marqueeText = fileName;
    marqueeStartedAt = millis();
  }

  String marquee = fileName + F("   ");
  int maxOffset = marquee.length() - visibleChars;
  if (maxOffset < 0) maxOffset = 0;

  int offset = 0;
  const unsigned long initialPauseMs = 400;
  const unsigned long loopPauseMs = 400;
  const unsigned long stepMs = 200;
  unsigned long elapsed = millis() - marqueeStartedAt;
  if (maxOffset > 0 && elapsed >= initialPauseMs) {
    unsigned long scrollDuration = static_cast<unsigned long>(maxOffset) * stepMs;
    unsigned long cycleDuration = scrollDuration + loopPauseMs + scrollDuration + loopPauseMs;
    unsigned long cyclePosition = (elapsed - initialPauseMs) % cycleDuration;
    if (cyclePosition < scrollDuration) {
      offset = cyclePosition / stepMs;
    } else if (cyclePosition < scrollDuration + loopPauseMs) {
      offset = maxOffset;
    } else if (cyclePosition < scrollDuration + loopPauseMs + scrollDuration) {
      offset = maxOffset - ((cyclePosition - scrollDuration - loopPauseMs) / stepMs);
    }
  }

  display.setCursor(x, y);
  display.print(marquee.substring(offset, offset + visibleChars));
}

void OLED_printKey(tpKeyData* kd, String fileName, bool isSending) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setTextWrap(false);
  uint8_t dataY = 14;
  if (fileName != "") {
    display.setCursor(3, 3);
    display.print(F("File: "));
    subGHzPrintFileName(display, fileName, 39, 3);
    dataY = 14;
  } else {
    display.setCursor(3, 3);
    display.println("Signal:");
    dataY = display.getCursorY() + 3;
  }
  String st = "";
  if (kd->type == kLINEAR) {
    st = "Unknown";
  } else {
    bool leadingZero = true;
    for (int i = 0; i < 8; i++) {
      if (kd->keyID[i] != 0 || !leadingZero || i == 7) {
        leadingZero = false;
        if (kd->keyID[i] < 0x10) st += "0";
        st += String(kd->keyID[i], HEX);
        if (i < 7) st += ":";
      }
    }
  }
  display.setCursor(3, dataY);
  display.println("Code: " + st);
  st = "Type: " + getTypeName(kd->type);
  dataY = display.getCursorY() + 2;
  display.setCursor(3, dataY);
  display.println(st);
  st = "Freq: " + String(kd->frequency) + " MHz";
  dataY = display.getCursorY() + 2;
  display.setCursor(3, dataY);
  display.println(st);
  if (kd->bitLength > 0) {
    st = "Bits: " + String(kd->bitLength);
    dataY = display.getCursorY() + 2;
    display.setCursor(3, dataY);
    display.println(st);
  }
  if (isSending) {
    display.setCursor(67, 54);
    display.print("Sending...");
    display.drawBitmap(109, 40, image_satellite_dish_bits, 15, 16, SH110X_WHITE);
  }
  display.display();
}

void OLED_printError(String st, bool err) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(3, 3);
  display.print(err ? F("Error!") : F("OK"));
  display.setCursor(1, 12);
  display.print(st);
  display.display();
}

void OLED_printCC1101InitError() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setTextWrap(false);
  display.setCursor(8, 20);
  display.print(F("CC1101 init failed."));
  display.setCursor(29, 32);
  display.print(F("ERROR: 0x001"));
  display.display();
}

void waitBackFromCC1101InitError() {
  resetButtonStates();
  while (digitalRead(BUTTON_BACK) == LOW) {
    buttonBack.tick();
    delay(10);
  }

  resetButtonStates();
  while (true) {
    buttonBack.tick();
    if (buttonBack.isClick()) {
      resetButtonStates();
      return;
    }
    delay(10);
  }
}

static void ensureSubExplorerDir() {
  if (subExplorer.currentDir.length() == 0) {
    subExplorer.currentDir = subExplorerCfg.rootDir;
  }
}

static int signalNumberFromName(String name) {
  int lastSlash = name.lastIndexOf('/');
  if (lastSlash >= 0) name = name.substring(lastSlash + 1);
  if (!(name.startsWith("Signal_") || name.startsWith("signal_")) || !name.endsWith(".sub")) {
    return 0;
  }

  String numStr = name.substring(7, name.length() - 4);
  if (numStr.length() == 0) {
    return 0;
  }
  for (uint16_t i = 0; i < numStr.length(); i++) {
    if (!isDigit(numStr[i])) {
      return 0;
    }
  }

  return numStr.toInt();
}

void syncNextSignalIndexFromFiles() {
  ensureSubExplorerDir();

  int maxSignalIndex = 0;
  File dir = SD.open(subExplorer.currentDir);
  if (dir) {
    while (true) {
      File entry = dir.openNextFile();
      if (!entry) break;
      if (!entry.isDirectory() && String(entry.name()).endsWith(".sub")) {
        int num = signalNumberFromName(entry.name());
        if (num > maxSignalIndex) {
          maxSignalIndex = num;
        }
      }
      entry.close();
    }
    dir.close();
  }

  int scannedNextIndex = maxSignalIndex + 1;
  if (scannedNextIndex < 1) scannedNextIndex = 1;
  nextSignalIndex = scannedNextIndex;
  nextSignalIndexReady = true;
}

String allocateNextSignalFileName() {
  ensureSubExplorerDir();
  syncNextSignalIndexFromFiles();

  int fileNum = (nextSignalIndex > 0) ? nextSignalIndex : 1;
  String fileName;
  while (fileNum <= 999) {
    fileName = subExplorer.currentDir + "/Signal_" + String(fileNum) + ".sub";
    if (!SD.exists(fileName)) break;
    fileNum++;
  }
  if (fileNum > 999) {
    Serial.println(F("No free Signal_*.sub slots"));
    return "";
  }

  nextSignalIndex = fileNum + 1;
  nextSignalIndexReady = true;
  return fileName;
}

bool startRawRecorderSession() {
  String fileName = allocateNextSignalFileName();
  if (fileName.length() == 0) {
    return false;
  }

  File file = SD.open(fileName, FILE_WRITE);
  if (!file) return false;

  file.println(F("Filetype: Flipper SubGhz RAW File"));
  file.println(F("Version: 1"));
  file.print(F("Frequency: "));
  file.println((unsigned long)(frequency * 1000000));
  file.println(F("Preset: FuriHalSubGhzPresetOok650Async"));
  file.println(F("Protocol: RAW"));
  file.close();

  rawRecorderSessionFile = fileName;
  int lastSlash = fileName.lastIndexOf('/');
  rawRecorderLastFile = (lastSlash >= 0) ? fileName.substring(lastSlash + 1) : fileName;
  rawRecorderEdgeCount = 0;
  pinMode(cc1101GDO0Pin, INPUT);
  rawRecorderPrevLevel = digitalRead(cc1101GDO0Pin);
  rawRecorderPrevEdgeUs = micros();
  rawRecorderLastEdgeUs = rawRecorderPrevEdgeUs;
  Serial.print(F("RAW session started: "));
  Serial.println(fileName);
  return true;
}

bool saveRawFrameToSession(const String& rawData, float rssi) {
  (void)rssi;
  if (rawRecorderSessionFile.length() == 0 || rawData.length() == 0) {
    return false;
  }

  File file = SD.open(rawRecorderSessionFile, FILE_APPEND);
  if (!file) return false;
  file.print(F("RAW_Data: "));
  file.println(rawData);
  file.close();
  return true;
}

void flushRawRecorderFrame() {
  if (rawRecorderEdgeCount < RAW_REC_MIN_EDGES) {
    rawRecorderEdgeCount = 0;
    return;
  }

  rawRecorderLastRssi = ELECHOUSE_cc1101.getRssi();
  if (rawRecorderLastRssi < rawRecorderRssiThreshold) {
    rawRecorderEdgeCount = 0;
    return;
  }

  String data = "";
  for (int i = 0; i < rawRecorderEdgeCount; i++) {
    if (i > 0) data += " ";
    data += String(rawRecorderEdges[i]);
  }

  if (saveRawFrameToSession(data, rawRecorderLastRssi)) {
    rawRecorderSavedCount++;
  }
  rawRecorderEdgeCount = 0;
}

void stopRawRecorderSession(bool flushPending, bool discardFile) {
  String fileToDiscard = rawRecorderSessionFile;
  if (flushPending) {
    flushRawRecorderFrame();
  } else {
    rawRecorderEdgeCount = 0;
  }
  rawRecorderSessionFile = "";
  if (discardFile && fileToDiscard.length() > 0 && SD.exists(fileToDiscard)) {
    SD.remove(fileToDiscard);
  }
}

void handleRawRecorderCapture() {
  unsigned long nowUs = micros();
  int level = digitalRead(cc1101GDO0Pin);

  if (level != rawRecorderPrevLevel) {
    unsigned long durUs = nowUs - rawRecorderPrevEdgeUs;
    rawRecorderPrevEdgeUs = nowUs;
    rawRecorderLastEdgeUs = nowUs;

    if (durUs >= 40 && durUs <= 60000 && rawRecorderEdgeCount < RAW_REC_MAX_EDGES) {
      int signedDur = rawRecorderPrevLevel ? (int)durUs : -(int)durUs;
      rawRecorderEdges[rawRecorderEdgeCount++] = signedDur;
    } else if (durUs > 60000 && rawRecorderEdgeCount >= RAW_REC_MIN_EDGES) {
      flushRawRecorderFrame();
    } else if (rawRecorderEdgeCount >= RAW_REC_MAX_EDGES) {
      flushRawRecorderFrame();
    }

    rawRecorderPrevLevel = level;
  }

  if (rawRecorderEdgeCount >= RAW_REC_MIN_EDGES && (nowUs - rawRecorderLastEdgeUs) > RAW_REC_FRAME_GAP_US) {
    flushRawRecorderFrame();
    rawRecorderPrevEdgeUs = nowUs;
    rawRecorderLastEdgeUs = nowUs;
  }
}

bool saveKeyToSD(tpKeyData* kd) {
  if (!kd || kd->codeLenth == 0 || kd->frequency == 0.0) {
    return false;
  }
  String fileName = allocateNextSignalFileName();
  if (fileName.length() == 0) {
    return false;
  }
  File file = SD.open(fileName, FILE_WRITE);
  if (!file) {
    Serial.print(F("Failed to open file for writing: "));
    Serial.println(fileName);
    return false;
  }
  file.println(F("Filetype: Flipper SubGhz Key File"));
  file.println(F("Version: 1"));
  file.print(F("Frequency: "));
  file.println((unsigned long)(kd->frequency * 1000000));
  file.print(F("Protocol: "));
  file.println(getTypeName(kd->type));
  file.print(F("Bit: "));
  file.println(kd->bitLength);
  file.print(F("Key: "));
  for (int i = 0; i < 8; i++) {
    if (kd->keyID[i] < 0x10) file.print("0");
    file.print(kd->keyID[i], HEX);
    if (i < 7) file.print(" ");
  }
  file.println();
  file.print(F("TE: "));
  file.println(kd->te);
  file.close();
  Serial.print(F("Saved to "));
  Serial.println(fileName);
  return true;
}

bool loadKeyFromSD(String fileName, tpKeyData* kd) {
  ensureSubExplorerDir();
  File file = SD.open(subExplorer.currentDir + "/" + fileName, FILE_READ);
  if (!file) {
    Serial.print(F("Failed to open file: "));
    Serial.println(fileName);
    return false;
  }
  memset(kd, 0, sizeof(tpKeyData));
  String line;
  while (file.available()) {
    line = file.readStringUntil('\n');
    line.trim();
    if (line.startsWith("Filetype:")) {
      bool isKeyFile = line.equals("Filetype: Flipper SubGhz Key File");
      bool isRawFile = line.equals("Filetype: Flipper SubGhz RAW File");
      if (!isKeyFile && !isRawFile) {
        file.close();
        Serial.print(F("Invalid file format: "));
        Serial.println(fileName);
        return false;
      }
    } else if (line.startsWith("Frequency:")) {
      kd->frequency = line.substring(10).toFloat() / 1000000.0;
    } else if (line.startsWith("Protocol:")) {
      String protocol = line.substring(9);
      protocol.trim();
      if (protocol == "Princeton") kd->type = kPrinceton;
      else if (protocol == "RcSwitch") kd->type = kRcSwitch;
      else if (protocol == "CAME") kd->type = kCAME;
      else if (protocol == "NICE") kd->type = kNICE;
      else if (protocol == "HOLTEK") kd->type = kHOLTEK;
      else if (protocol == "KeeLoq") kd->type = kKeeLoq;
      else if (protocol == "StarLine") kd->type = kStarLine;
      else if (protocol == "RAW") kd->type = kLINEAR;
      else kd->type = kUnknown;
    } else if (line.startsWith("Bit:")) {
      kd->bitLength = line.substring(4).toInt();
      kd->codeLenth = kd->bitLength;
    } else if (line.startsWith("Key:")) {
      String keyStr = line.substring(4);
      keyStr.trim();
      keyStr.replace(" ", "");
      for (int i = 0; i < keyStr.length() / 2 && i < 8; i++) {
        String byteStr = keyStr.substring(i * 2, i * 2 + 2);
        kd->keyID[i] = strtol(byteStr.c_str(), NULL, 16);
      }
    } else if (line.startsWith("TE:")) {
      kd->te = line.substring(3).toInt();
    } else if (line.startsWith("RAW_Data:")) {
      String rawLine = line.substring(9);
      rawLine.trim();
      strncpy(kd->rawData, rawLine.c_str(), sizeof(kd->rawData) - 1);
      kd->rawData[sizeof(kd->rawData) - 1] = '\0';
      kd->type = kLINEAR;
      kd->codeLenth = 1;
      // RAW is transmitted directly from SD; do not load the whole file
      // into a String while opening file information.
      break;
    }
  }
  file.close();
  return true;
}


void OLED_printBruteIntro() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(1);
  display.setTextWrap(false);
  display.setCursor(69, 22);
  display.print(F("to config"));
  display.setCursor(76, 13);
  display.print(F("Hold OK"));
  display.drawBitmap(77, 36, image_AntLogo_bits, 38, 22, 1);
  display.drawBitmap(0, 10, image_DolphinWait_bits, 59, 54, 1);
  display.display();
}

static int16_t getBruteConfigArrowY(uint8_t selection) {
  return selection == 0 ? 24 : 36;
}

static void drawBruteConfigFrame(int16_t arrowY = -1) {
  if (arrowY < 0) arrowY = getBruteConfigArrowY(bruteConfigSelection);

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(1);
  display.setTextWrap(false);

  display.setCursor(3, 2);
  display.print(F("Bruteforce"));
  display.setCursor(1, 10);
  display.print(F("====================="));

  display.setCursor(7, 24);
  display.print(F("Type: "));
  String typeLabel = String(bruteTypes[bruteTypeIndex]) + "-" + String(bruteBits);
  if (bruteTypeIndex != 4) typeLabel += F("bit");
  display.print(typeLabel);

  display.setCursor(7, 36);
  display.print(F("Freq: "));
  display.print(bruteFreqLabels[bruteFreqIndex]);

  display.setCursor(1, arrowY);
  display.print(F(">"));
  display.display();
}

void OLED_printBruteConfig(int previousSelection) {
  if (previousSelection < 0 || previousSelection == bruteConfigSelection) {
    drawBruteConfigFrame();
    return;
  }

  int16_t fromY = getBruteConfigArrowY(previousSelection);
  int16_t toY = getBruteConfigArrowY(bruteConfigSelection);
  const byte steps = 4;
  for (byte step = 1; step <= steps; step++) {
    int progress = (step * 100) / steps;
    int eased = progress < 50
      ? (2 * progress * progress) / 100
      : 100 - (2 * (100 - progress) * (100 - progress)) / 100;
    int16_t arrowY = fromY + ((toY - fromY) * eased) / 100;
    drawBruteConfigFrame(arrowY);
    delay(1);
  }
  drawBruteConfigFrame(toY);
}

void OLED_printBruteProgress(uint16_t progress, uint16_t total) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(1);
  display.setTextWrap(false);
  int signalDigits = (progress < 10) ? 1 : (progress < 100) ? 2 : (progress < 1000) ? 3 : 4;
  int signalX = 69;
  switch (signalDigits) {
    case 1: signalX = 78; break;
    case 2: signalX = 75; break;
    case 3: signalX = 72; break;
    default: signalX = 69; break;
  }
  display.setCursor(signalX, 24);
  char buf[18];
  snprintf(buf, sizeof(buf), "%u/%u", progress, total);
  display.print(buf);
  display.drawBitmap(77, 36, image_AntLogoON_bits, 38, 22, 1);
  display.drawBitmap(0, 10, image_DolphinWait_bits, 59, 54, 1);
  uint16_t percent = (total == 0) ? 0 : (progress * 100) / total;
  int percentDigits = (percent < 10) ? 1 : (percent < 100) ? 2 : 3;
  int percentX = -1;
  switch (percentDigits) {
    case 1: percentX = 85; break;
    case 2: percentX = 79; break;
    case 3: percentX = 73; break;
    default: percentX = -1; break;
  }
  if (percentX >= 0) {
    display.setTextSize(2);
    display.setCursor(percentX, 6);
    if (percent > 100) percent = 100;
    snprintf(buf, sizeof(buf), "%u%%", percent);
    display.print(buf);
    display.setTextSize(1);
  }
  display.display();
}

const BruteProtocol* getBruteProtocolByIndex(int idx) {
  switch (idx) {
    case 0: return &protoCame;
    case 1: return &protoNice;
    case 2: return &protoAnsonic;
    case 3: return &protoHoltek;
    case 4: return &protoChamber;
    default: return nullptr;
  }
}

bool bruteInitTx() {
  currentBruteProto = getBruteProtocolByIndex(bruteTypeIndex);
  if (!currentBruteProto) return false;
  freqIndex = bruteFreqIndex;
  frequency = bruteFreqOptions[bruteFreqIndex];
  bruteTxPin = (bruceConfig.rfModule == CC1101_SPI_MODULE) ? bruceConfigPins.CC1101_bus.io0 : bruceConfig.rfTx;
  if (!initRfModule("tx", frequency)) return false;
  pinMode(bruteTxPin, OUTPUT);
  digitalWrite(bruteTxPin, LOW);
  bruteRfActive = true;
  return true;
}

void bruteStopTx() {
  if (!bruteRfActive) return;
  digitalWrite(bruteTxPin, LOW);
  deinitRfModule();
  bruteRfActive = false;
}

void bruteSendSequence(const int* seq, size_t len) {
  if (!seq || len == 0) return;
  for (size_t i = 0; i < len; i++) {
    int duration = seq[i];
    bool levelHigh = duration > 0;
    unsigned int delayVal = (duration > 0) ? duration : -duration;
    digitalWrite(bruteTxPin, levelHigh ? HIGH : LOW);
    delayMicroseconds(delayVal);
  }
}

void bruteSendCode(uint16_t code) {
  if (!bruteRfActive || !currentBruteProto) return;
  const BruteProtocol* p = currentBruteProto;

  bruteSendSequence(p->pilot, p->pilotLen);
  for (int bit = bruteBits - 1; bit >= 0; --bit) {
    bool set = (code >> bit) & 0x1;
    bruteSendSequence(set ? p->one : p->zero, set ? p->oneLen : p->zeroLen);
  }
  bruteSendSequence(p->stop, p->stopLen);
  digitalWrite(bruteTxPin, LOW);
}

static bool rawPlaybackStopRequested();

static bool sendRawBlock(const String& block) {
  String line = block;
  line.trim();
  if (line.length() == 0) return false;

  int transmittimings[RAW_REC_MAX_EDGES + 1];
  int count = 0;
  int startIndex = 0;

  while (startIndex < line.length() && count < RAW_REC_MAX_EDGES) {
    if (rawPlaybackActive && rawPlaybackStopRequested()) return false;
    while (startIndex < line.length() && line[startIndex] == ' ') startIndex++;
    if (startIndex >= line.length()) break;
    int index = line.indexOf(' ', startIndex);
    if (index < 0) index = line.length();
    String token = line.substring(startIndex, index);
    token.trim();
    if (token.length() > 0) {
      transmittimings[count++] = token.toInt();
    }
    startIndex = index + 1;
  }

  if (count <= 0) return false;
  transmittimings[count] = 0;
  RCSwitch_RAW_send(transmittimings);
  return true;
}

static void updateRawPlaybackStopFromPins() {
  bool okDown = digitalRead(BUTTON_OK) == LOW;
  bool backDown = digitalRead(BUTTON_BACK) == LOW;
  unsigned long now = millis();

  if (rawPlaybackIgnoreOkRelease) {
    if (!okDown) {
      rawPlaybackIgnoreOkRelease = false;
    }
  } else if (okDown) {
    rawPlaybackOkWasPressed = true;
  }

  if (rawPlaybackIgnoreBackRelease) {
    if (!backDown) {
      rawPlaybackIgnoreBackRelease = false;
      rawPlaybackBackWasPressed = false;
      rawPlaybackBackPressedAt = 0;
    }
  } else if (backDown) {
    if (!rawPlaybackBackWasPressed) {
      rawPlaybackBackWasPressed = true;
      rawPlaybackBackPressedAt = now;
    }
  }

  if (rawPlaybackOkWasPressed && !okDown) {
    rawPlaybackStopRequestedFlag = true;
  }

  if (rawPlaybackBackWasPressed && !backDown) {
    if (now - rawPlaybackBackPressedAt <= BUTTON_RELEASE_CLICK_MS) {
      rawPlaybackStopRequestedFlag = true;
    }
    rawPlaybackBackWasPressed = false;
    rawPlaybackBackPressedAt = 0;
  }
}

static bool rawPlaybackStopRequested() {
  buttonOK.tick();
  buttonBack.tick();
  updateRawPlaybackStopFromPins();
  return rawPlaybackStopRequestedFlag;
}

void drawRawPlaybackWave(float phase, uint8_t progressPct) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setTextWrap(false);
  display.setCursor(5, 3);
  display.print(String(frequency, 2) + F("MHz"));

  if (progressPct > 100) progressPct = 100;
  String progress = String(progressPct) + F("%");
  display.setCursor(123 - progress.length() * 6, 3);
  display.print(progress);

  display.drawRect(10, 13, 108, 37, SH110X_WHITE);
  static const int8_t rawWaveSin[64] = {
    0, 3, 6, 9, 12, 16, 19, 22, 25, 28, 31, 34, 37,
    40, 43, 46, 49, 51, 54, 57, 60, 63, 65, 68, 71, 73,
    76, 78, 81, 83, 85, 88, 90, 92, 94, 96, 98, 100, 102,
    104, 106, 107, 109, 111, 112, 113, 115, 116, 117, 118, 120, 121,
    122, 122, 123, 124, 125, 125, 126, 126, 126, 127, 127, 127
  };

  auto rawWaveSinValue = [&](uint8_t x) -> int8_t {
    int8_t value = rawWaveSin[((x & 0x40) ? -x - 1 : x) & 0x3F];
    return (x & 0x80) ? -value : value;
  };

  const uint8_t phaseIndex = ((uint32_t)(phase / 9.0f)) % 63;
  const int8_t amplitude = 11;
  for (int i = 113; i > 0; i--) {
    const int x1 = 12 + ((i - 1) * 103) / 112;
    const int x2 = min(115, 12 + (i * 103) / 112);
    const int x3 = min(115, 12 + ((i + 1) * 103) / 112);
    const int y1 = 32 - rawWaveSinValue(i + phaseIndex * 16) / amplitude;
    const int y2 = 32 + rawWaveSinValue((i + phaseIndex * 16 + 1) * 2) / amplitude;
    display.drawLine(x1, y1, x2, y2, SH110X_WHITE);
    display.drawLine(x2, y1, x3, y2, SH110X_WHITE);
  }

  const char* label = "Stop";
  const uint8_t textW = strlen(label) * 6;
  const uint8_t iconW = 9;
  const uint8_t iconH = 9;
  const uint8_t gap = 3;
  const uint8_t contentW = textW + gap + iconW;
  const uint8_t padX = 5;
  const uint8_t btnX = (SCREEN_WIDTH - (contentW + padX * 2)) / 2;
  const uint8_t btnY = 52;
  const uint8_t btnW = contentW + padX * 2;
  const uint8_t btnH = 12;

  display.fillRoundRect(btnX, btnY, btnW, btnH, 2, SH110X_WHITE);
  display.fillRect(btnX, btnY + 2, btnW, btnH - 2, SH110X_WHITE);
  display.setTextColor(SH110X_BLACK);
  display.setCursor(btnX + padX, btnY + 3);
  display.print(label);
  display.drawBitmap(btnX + padX + textW + gap, btnY + 2, image_REC_bits, iconW, iconH, SH110X_BLACK);
  display.setTextColor(SH110X_WHITE);
  display.display();
}

static void setRawPlaybackTarget(float targetPct) {
  if (targetPct > 100.0f) targetPct = 100.0f;
  if (targetPct < rawPlaybackTargetPct) targetPct = rawPlaybackTargetPct;
  rawPlaybackTargetPct = targetPct;
}

static void pumpRawPlaybackAnimation(bool force = false) {
  if (!rawPlaybackActive) return;

  unsigned long now = millis();
  if (!force && now - rawPlaybackLastDrawMs < 18) return;
  rawPlaybackLastDrawMs = now;

  float delta = rawPlaybackTargetPct - rawPlaybackShownPct;
  rawPlaybackShownPct += delta * 0.16f;
  if (fabs(delta) < 0.35f) {
    rawPlaybackShownPct = rawPlaybackTargetPct;
  }

  float phase = (float)(now - rawPlaybackStartMs) * 0.1f;
  drawRawPlaybackWave(phase, (uint8_t)(rawPlaybackShownPct + 0.5f));
}

static void rawPlaybackAnimationTask(void* parameter) {
  (void)parameter;
  while (rawPlaybackActive) {
    updateRawPlaybackStopFromPins();
    pumpRawPlaybackAnimation();
    delay(8);
  }
  rawPlaybackTaskHandle = nullptr;
  vTaskDelete(nullptr);
}

static void startRawPlaybackAnimationTask() {
  if (rawPlaybackTaskHandle != nullptr) return;
  xTaskCreatePinnedToCore(
    rawPlaybackAnimationTask,
    "raw_play_anim",
    4096,
    nullptr,
    1,
    &rawPlaybackTaskHandle,
    0
  );
}

static void stopRawPlaybackAnimationTask() {
  rawPlaybackActive = false;
  unsigned long startMs = millis();
  while (rawPlaybackTaskHandle != nullptr && millis() - startMs < 120) {
    delay(4);
  }
}

static void armRawPlaybackReleaseGuards() {
  if (digitalRead(BUTTON_OK) == LOW) {
    rawRecorderIgnoreOkRelease = true;
    transmitIgnoreOkRelease = true;
  }
  if (digitalRead(BUTTON_BACK) == LOW) {
    rawRecorderIgnoreBackRelease = true;
    transmitIgnoreBackRelease = true;
  }
  buttonOK.resetStates();
  buttonBack.resetStates();
}

static void finishRawPlaybackAnimation(uint16_t durationMs) {
  setRawPlaybackTarget(100.0f);
  unsigned long startMs = millis();
  while (!rawPlaybackStopRequested() && millis() - startMs < durationMs) {
    delay(18);
  }
}

static void rawPlaybackDelayMicroseconds(unsigned int durationUs) {
  while (durationUs > 0) {
    if (rawPlaybackActive && rawPlaybackStopRequested()) return;
    const unsigned int slice = durationUs > 500 ? 500 : durationUs;
    delayMicroseconds(slice);
    durationUs -= slice;
  }
}

bool playRawRecorderFile(const String& fileName) {
  rawPlaybackActive = false;
  rawPlaybackStopRequestedFlag = false;
  rawPlaybackOkWasPressed = false;
  rawPlaybackBackWasPressed = false;
  rawPlaybackBackPressedAt = 0;
  rawPlaybackIgnoreOkRelease = false;
  rawPlaybackIgnoreBackRelease = false;
  rawPlaybackShownPct = 0.0f;
  rawPlaybackTargetPct = 0.0f;
  rawPlaybackStartMs = millis();
  rawPlaybackLastDrawMs = 0;

  if (fileName.length() == 0 || !SD.exists(fileName)) {
    OLED_printError(F("No RAW file"), true);
    delay(600);
    return false;
  }

  // RAW uses the GDO0 pin for transmission. Stop the receive interrupt
  // before switching the CC1101 into TX mode.
  disableRcSwitchReceive();

  rawPlaybackActive = true;
  rawPlaybackIgnoreOkRelease = digitalRead(BUTTON_OK) == LOW;
  rawPlaybackIgnoreBackRelease = digitalRead(BUTTON_BACK) == LOW;
  drawRawPlaybackWave(0, 0);
  startRawPlaybackAnimationTask();

  if (!initRfModule("tx", frequency)) {
    stopRawPlaybackAnimationTask();
    rawPlaybackActive = false;
    OLED_printError(F("TX init fail"), true);
    delay(800);
    restoreReceiveMode();
    return false;
  }

  ELECHOUSE_cc1101.setModulation(2);
  ELECHOUSE_cc1101.setRxBW(270.0);
  ELECHOUSE_cc1101.setDeviation(0);
  ELECHOUSE_cc1101.setDRate(10);
  ELECHOUSE_cc1101.setPA(12);
  ELECHOUSE_cc1101.SetTx();
  pinMode(bruceConfigPins.CC1101_bus.io0, OUTPUT);

  File rawFile = SD.open(fileName, FILE_READ);
  if (!rawFile) {
    stopRawPlaybackAnimationTask();
    rawPlaybackActive = false;
    deinitRfModule();
    restoreReceiveMode();
    OLED_printError(F("Open failed"), true);
    delay(600);
    return false;
  }

  int sentBlocks = 0;
  const uint32_t rawFileSize = rawFile.size();
  bool foundRawBlock = false;

  while (rawFile.available()) {
    if (rawPlaybackStopRequested()) break;

    String line = rawFile.readStringUntil('\n');
    line.trim();
    if (!line.startsWith("RAW_Data:")) continue;

    String block = line.substring(9);
    block.trim();
    foundRawBlock = true;
    // File position provides progress without a separate full SD pass.
    float targetPct = rawFileSize > 0
        ? ((float)rawFile.position() * 100.0f / (float)rawFileSize)
        : 100.0f;
    if (targetPct < 1.0f) targetPct = 1.0f;
    setRawPlaybackTarget(targetPct);
    if (sendRawBlock(block)) {
      sentBlocks++;
    }
  }
  rawFile.close();

  if (!rawPlaybackStopRequestedFlag && foundRawBlock) {
    setRawPlaybackTarget(100.0f);
    finishRawPlaybackAnimation(180);
  }

  stopRawPlaybackAnimationTask();
  armRawPlaybackReleaseGuards();
  deinitRfModule();
  restoreReceiveMode();

  return sentBlocks > 0;
}


void sendSynthKey(tpKeyData* kd) {
  Serial.println(F("Starting transmission"));
  String protocol = getTypeName(kd->type);
  if (protocol != "RAW") {
    OLED_printKey(kd, subExplorer.selectedFile, true);
  }

  Serial.print(F("Transmitting key, protocol: "));
  Serial.print(getTypeName(kd->type));
  Serial.print(F(", ID: "));
  for (byte i = 0; i < 8; i++) {
    if (kd->keyID[i] < 0x10) Serial.print("0");
    Serial.print(kd->keyID[i], HEX);
    if (i < 7) Serial.print(" ");
  }
  Serial.print(F(", Freq: "));
  Serial.print(kd->frequency);
  Serial.println(F(" MHz"));

  String data = String(kd->rawData);
  uint64_t key = 0;
  for (int i = 0; i < 8; i++) {
    key |= ((uint64_t)kd->keyID[i] << ((7 - i) * 8));
  }
  byte modulation = 2;
  float rxBW = 270.0;
  float deviation = 0;
  float dataRate = 10;

  int rcswitch_protocol_no = 1;

  if (protocol == "RAW" && subExplorer.selectedFile.length() > 0) {
    frequency = kd->frequency;
    String rawPath = subExplorer.currentDir + "/" + subExplorer.selectedFile;
    playRawRecorderFile(rawPath);
    OLED_printKey(kd, subExplorer.selectedFile);
    return;
  }

  if (!initRfModule("tx", kd->frequency)) {
    Serial.println(F("Failed to initialize CC1101"));
    OLED_printCC1101InitError();
    waitBackFromCC1101InitError();
    OLED_printKey(kd, subExplorer.selectedFile);
    return;
  }

  if (bruceConfig.rfModule == CC1101_SPI_MODULE) {
    ELECHOUSE_cc1101.setModulation(modulation);
    ELECHOUSE_cc1101.setRxBW(rxBW);
    ELECHOUSE_cc1101.setDeviation(deviation);
    ELECHOUSE_cc1101.setDRate(dataRate);
    pinMode(bruceConfigPins.CC1101_bus.io0, OUTPUT);
    ELECHOUSE_cc1101.setPA(12);
    ELECHOUSE_cc1101.SetTx();
  } else {
    if (modulation != 2) {
      Serial.print("unsupported modulation: ");
      Serial.println(modulation);
      OLED_printError(F("Unsupported modulation"), true);
      delay(1000);
      OLED_printKey(kd, subExplorer.selectedFile);
      deinitRfModule();
      return;
    }
    initRfModule("tx", kd->frequency);
  }

  bool transmissionSuccess = false;

  if (protocol == "RAW") {
    int sentBlocks = 0;
    int totalBlocks = 0;

    int countStart = 0;
    while (countStart < data.length()) {
      int countEnd = data.indexOf('\n', countStart);
      if (countEnd < 0) countEnd = data.length();
      String block = data.substring(countStart, countEnd);
      block.trim();
      if (block.length() > 0) totalBlocks++;
      countStart = countEnd + 1;
    }

    rawPlaybackActive = true;
    rawPlaybackStopRequestedFlag = false;
    rawPlaybackOkWasPressed = false;
    rawPlaybackBackWasPressed = false;
    rawPlaybackBackPressedAt = 0;
    rawPlaybackIgnoreOkRelease = digitalRead(BUTTON_OK) == LOW;
    rawPlaybackIgnoreBackRelease = digitalRead(BUTTON_BACK) == LOW;
    rawPlaybackShownPct = 0.0f;
    rawPlaybackTargetPct = 0.0f;
    rawPlaybackStartMs = millis();
    rawPlaybackLastDrawMs = 0;
    drawRawPlaybackWave(0, 0);
    startRawPlaybackAnimationTask();

    bool sentFromFile = false;
    if (subExplorer.selectedFile.length() > 0) {
      File rawFile = SD.open(subExplorer.currentDir + "/" + subExplorer.selectedFile, FILE_READ);
      if (rawFile) {
        while (rawFile.available()) {
          String line = rawFile.readStringUntil('\n');
          line.trim();
          if (!line.startsWith("RAW_Data:")) continue;
          String block = line.substring(9);
          block.trim();
          if (sendRawBlock(block)) {
            sentBlocks++;
            sentFromFile = true;
          }
        }
        rawFile.close();
      }
    }

    if (!sentFromFile) {
      int lineStart = 0;
      while (lineStart < data.length()) {
        int lineEnd = data.indexOf('\n', lineStart);
        if (lineEnd < 0) lineEnd = data.length();
        String block = data.substring(lineStart, lineEnd);
        lineStart = lineEnd + 1;
        block.trim();
        if (block.length() == 0) continue;
        float targetPct = (totalBlocks > 0) ? ((float)(sentBlocks + 1) * 100.0f / (float)totalBlocks) : 100.0f;
        setRawPlaybackTarget(targetPct);
        if (sendRawBlock(block)) {
          sentBlocks++;
        }
      }
    }

    if (!rawPlaybackStopRequestedFlag) {
      finishRawPlaybackAnimation(180);
    }
    stopRawPlaybackAnimationTask();
    armRawPlaybackReleaseGuards();

    transmissionSuccess = (sentBlocks > 0);
  } else if (protocol == "RcSwitch") {
    data.replace(" ", "");
    uint64_t data_val = key;
    int bits = kd->bitLength;
    int pulse = kd->te;
    int repeat = 10;
    display.setCursor(67, 54);
    display.print("Sending...");
    display.display();
    RCSwitch_send(data_val, bits, pulse, rcswitch_protocol_no, repeat);
    transmissionSuccess = true;
  } else if (protocol == "Princeton") {
    RCSwitch_send(key, kd->bitLength, 350, 1, 10);
    transmissionSuccess = true;
  } else {
    Serial.print("Unsupported protocol: ");
    Serial.println(protocol);
    RCSwitch_send(key, kd->bitLength, 270, 11, 10);
    transmissionSuccess = true;
  }

  deinitRfModule();

  OLED_printKey(kd, subExplorer.selectedFile);
}

void RCSwitch_send(uint64_t data, unsigned int bits, int pulse, int protocol, int repeat) {
  RCSwitch mySwitch = RCSwitch();

  int txPin = bruceConfig.rfTx;
  if (bruceConfig.rfModule == CC1101_SPI_MODULE) {
    txPin = bruceConfigPins.CC1101_bus.io0;
  }
  mySwitch.enableTransmit(txPin);

  mySwitch.setProtocol(protocol);
  if (pulse) { mySwitch.setPulseLength(pulse); }
  int rep = repeat > 0 ? repeat : 6;
  if (rep > 6) rep = 6;
  mySwitch.setRepeatTransmit(rep);
  mySwitch.send(data, bits);

  mySwitch.disableTransmit();
}

void RCSwitch_RAW_send(int *ptrtransmittimings) {
  int nTransmitterPin = bruceConfig.rfTx;
  if (bruceConfig.rfModule == CC1101_SPI_MODULE) {
    nTransmitterPin = bruceConfigPins.CC1101_bus.io0;
  }

  if (!ptrtransmittimings) return;

  bool hasNeg = false;
  unsigned long sum_us = 0;
  for (int i = 0; ptrtransmittimings[i]; ++i) {
    if (ptrtransmittimings[i] < 0) hasNeg = true;
    int v = ptrtransmittimings[i] >= 0 ? ptrtransmittimings[i] : -ptrtransmittimings[i];
    sum_us += (unsigned long)v;
  }
  int nRepeatTransmit = 1;
  if (sum_us > 0) {
    nRepeatTransmit = (int)(900000UL / sum_us);
    if (nRepeatTransmit < 1) nRepeatTransmit = 1;
    if (nRepeatTransmit > 6) nRepeatTransmit = 6;
  }
  if (rawPlaybackActive) {
    nRepeatTransmit = 1;
  }

  for (int nRepeat = 0; nRepeat < nRepeatTransmit; nRepeat++) {
    if (rawPlaybackActive && rawPlaybackStopRequested()) break;
    unsigned int currenttiming = 0;
    bool level = true;
    while (ptrtransmittimings[currenttiming]) {
      if (rawPlaybackActive && rawPlaybackStopRequested()) break;
      int dur = ptrtransmittimings[currenttiming];
      bool lvl;
      unsigned int t;
      if (hasNeg) {
        lvl = (dur >= 0);
        t = (unsigned int)(dur >= 0 ? dur : -dur);
      } else {
        lvl = level;
        t = (unsigned int)(dur >= 0 ? dur : -dur);
        level = !level;
      }
      digitalWrite(nTransmitterPin, lvl ? HIGH : LOW);
      rawPlaybackDelayMicroseconds(t);
      currenttiming++;
    }
    digitalWrite(nTransmitterPin, LOW);
    rawPlaybackDelayMicroseconds(8000);
  }
}

void stepFrequency(int step) {
  freqIndex = (freqIndex + step + numFrequencies) % numFrequencies;
  frequency = frequencies[freqIndex];
}

void analyzerInit() {
  for (uint8_t i = 0; i < ANALYZER_HIST_CNT; i++) {
    analyzerState.hist_freq[i] = 0;
    analyzerState.hist_count[i] = 0;
  }
  analyzerState.curr_freq = 0;
  analyzerState.saved_freq = 0;
  analyzerState.rssi_now = 0.0f;
  analyzerState.last_rssi = 0.0f;
  analyzerState.has_signal = false;
  analyzerState.threshold = ANALYZER_DEFAULT_TRIG;
  analyzerFilterVal = 0.0f;
  analyzerTrigLevel = ANALYZER_DEFAULT_TRIG;
  analyzerHoldCount = 0;
  analyzerLocked = false;
  analyzerDetectedFrequency = 0.0f;
  analyzerLastDraw = 0;

  ELECHOUSE_cc1101.SpiStrobe(0x36);
  delayMicroseconds(200);
  ELECHOUSE_cc1101.setRxBW(812.0);
  ELECHOUSE_cc1101.SetRx();
}

uint32_t analyzerSmoothAvg(uint32_t newVal) {
  float newFloat = (float)newVal;
  float mix = (fabsf(newFloat - analyzerFilterVal) > 500000.0f) ? 0.9f : 0.03f;
  analyzerFilterVal += (newFloat - analyzerFilterVal) * mix;
  return (uint32_t)analyzerFilterVal;
}

uint32_t analyzerNearestFreq(uint32_t input) {
  uint32_t prev = 0;
  uint32_t out = 0;
  for (int i = 0; i < ANALYZER_FREQ_COUNT; i++) {
    uint32_t cur = (uint32_t)(analyzerFreqs[i] * 1000000.0f);
    if (cur == 0) continue;
    if (cur == input) return cur;
    if (cur > input && prev < input) {
      out = (cur - input < input - prev) ? cur : prev;
      break;
    }
    prev = cur;
  }
  if (!out && prev) out = prev;
  return out;
}

void analyzerAddHistory(uint32_t freq) {
  uint32_t normFreq = analyzerNearestFreq(freq);
  if (!normFreq) return;

  bool found = false;
  for (uint8_t i = 0; i < ANALYZER_HIST_CNT; i++) {
    if (analyzerState.hist_freq[i] != normFreq) continue;
    found = true;
    if (analyzerState.hist_count[i] == 0) analyzerState.hist_count[i] = 1;
    else analyzerState.hist_count[i]++;

    if (i > 0) {
      uint32_t f = analyzerState.hist_freq[i];
      uint8_t c = analyzerState.hist_count[i];
      for (int j = i; j > 0; j--) {
        analyzerState.hist_freq[j] = analyzerState.hist_freq[j - 1];
        analyzerState.hist_count[j] = analyzerState.hist_count[j - 1];
      }
      analyzerState.hist_freq[0] = f;
      analyzerState.hist_count[0] = c;
    }
    break;
  }

  if (!found) {
    for (int i = ANALYZER_HIST_CNT - 1; i > 0; i--) {
      analyzerState.hist_freq[i] = analyzerState.hist_freq[i - 1];
      analyzerState.hist_count[i] = analyzerState.hist_count[i - 1];
    }
    analyzerState.hist_freq[0] = normFreq;
    analyzerState.hist_count[0] = 1;
  }
}

void analyzerSaveFreq() {
  if (!analyzerState.curr_freq) return;
  uint32_t saveFreq = analyzerNearestFreq(analyzerState.curr_freq);
  if (saveFreq && saveFreq != analyzerState.saved_freq) {
    analyzerState.saved_freq = saveFreq;
  }
}

bool analyzerHandleInput() {
  buttonUp.tick();
  buttonDown.tick();
  buttonOK.tick();
  buttonBack.tick();

  if (buttonBack.isClick()) {
    analyzerExitRequested = true;
    return false;
  }

  bool displayChanged = false;

  if (buttonDown.isClick()) {
    const float previousLevel = analyzerTrigLevel;

    analyzerTrigLevel -= ANALYZER_TRIG_STEP;

    if (analyzerTrigLevel < ANALYZER_RSSI_LOW) {
      analyzerTrigLevel = ANALYZER_RSSI_LOW;
    }

    displayChanged = analyzerTrigLevel != previousLevel;

    Serial.printf(
      "[Analyzer] Trigger: %.0f dBm\n",
      analyzerTrigLevel
    );
  }

  if (buttonUp.isClick()) {
    const float previousLevel = analyzerTrigLevel;

    if (analyzerTrigLevel == ANALYZER_RSSI_LOW) {
      analyzerTrigLevel = -95.0f;
    } else {
      analyzerTrigLevel += ANALYZER_TRIG_STEP;
    }

    if (analyzerTrigLevel > ANALYZER_RSSI_HIGH) {
      analyzerTrigLevel = ANALYZER_RSSI_HIGH;
    }

    displayChanged = analyzerTrigLevel != previousLevel;

    Serial.printf(
      "[Analyzer] Trigger: %.0f dBm\n",
      analyzerTrigLevel
    );
  }

  if (buttonOK.isClick()) {
    analyzerSaveFreq();
    displayChanged = true;

    Serial.printf(
      "[Analyzer] Saved frequency: %lu Hz\n",
      analyzerState.saved_freq
    );
  }

  analyzerState.threshold = analyzerTrigLevel;

  if (displayChanged) {
    OLED_printAnalyzer();
    analyzerLastDraw = millis();
  }

  return true;
}

void analyzerDoScan() {
  bool hadSignal = analyzerState.has_signal;
  uint32_t prevFreq = analyzerState.curr_freq;
  analyzerScanResult.rough_rssi = -127.0f;
  analyzerScanResult.fine_rssi = -127.0f;

  ELECHOUSE_cc1101.SpiStrobe(0x36);
  ELECHOUSE_cc1101.setRxBW(812.0);

  for (int i = 0; i < ANALYZER_FREQ_COUNT; i++) {
    if (!analyzerHandleInput()) {
      return;
    }

    uint32_t freqHz = (uint32_t)(analyzerFreqs[i] * 1000000.0f);
    if (freqHz == 462750000 || freqHz == 467750000 || freqHz == 464000000 || freqHz > 920000000) {
      continue;
    }
    if (analyzerIsNoiseFreq(freqHz)) {
      continue;
    }

    ELECHOUSE_cc1101.setMHZ(analyzerFreqs[i]);
    ELECHOUSE_cc1101.SetRx();
    delayMicroseconds(ANALYZER_STEP_DELAY_US);

    float rssi = ELECHOUSE_cc1101.getRssi();
    if (analyzerScanResult.rough_rssi < rssi) {
      analyzerScanResult.rough_rssi = rssi;
      analyzerScanResult.rough_freq = freqHz;
    }
  }

  if (analyzerScanResult.rough_rssi > analyzerTrigLevel && analyzerScanResult.rough_freq > 300000) {
    ELECHOUSE_cc1101.SpiStrobe(0x36);
    ELECHOUSE_cc1101.setRxBW(58.0);
    for (uint32_t freqHz = analyzerScanResult.rough_freq - 300000;
         freqHz < analyzerScanResult.rough_freq + 300000;
         freqHz += 20000) {

      if (!analyzerHandleInput()) {
        return;
      }
      if (analyzerIsNoiseFreq(freqHz)) {
        continue;
      }
      float freqMHz = freqHz / 1000000.0f;
      ELECHOUSE_cc1101.setMHZ(freqMHz);
      ELECHOUSE_cc1101.SetRx();
      delayMicroseconds(ANALYZER_STEP_DELAY_US);

      float rssi = ELECHOUSE_cc1101.getRssi();
      if (analyzerScanResult.fine_rssi < rssi) {
        analyzerScanResult.fine_rssi = rssi;
        analyzerScanResult.fine_freq = freqHz;
      }
    }
  }

  if (analyzerScanResult.fine_rssi > analyzerTrigLevel + ANALYZER_LOCK_MARGIN_DB &&
      !analyzerIsNoiseFreq(analyzerScanResult.fine_freq)) {
    analyzerHoldCount = 20;
    if (analyzerFilterVal != 0.0f) {
      analyzerScanResult.fine_freq = analyzerSmoothAvg(analyzerScanResult.fine_freq);
    }
    analyzerLocked = true;
    analyzerState.curr_freq = analyzerScanResult.fine_freq;
    analyzerState.rssi_now = analyzerScanResult.fine_rssi;
    analyzerState.last_rssi = analyzerScanResult.fine_rssi;
    analyzerState.has_signal = true;
    analyzerDetectedFrequency = analyzerState.curr_freq / 1000000.0f;
  } else if (analyzerScanResult.rough_rssi > analyzerTrigLevel + ANALYZER_LOCK_MARGIN_DB &&
             analyzerHoldCount < 10 &&
             !analyzerIsNoiseFreq(analyzerScanResult.rough_freq)) {
    analyzerHoldCount = 20;
    if (analyzerFilterVal != 0.0f) {
      analyzerScanResult.rough_freq = analyzerSmoothAvg(analyzerScanResult.rough_freq);
    }
    analyzerLocked = true;
    analyzerState.curr_freq = analyzerScanResult.rough_freq;
    analyzerState.rssi_now = analyzerScanResult.rough_rssi;
    analyzerState.last_rssi = analyzerScanResult.rough_rssi;
    analyzerState.has_signal = true;
    analyzerDetectedFrequency = analyzerState.curr_freq / 1000000.0f;
  } else {
    analyzerLocked = false;
    analyzerState.has_signal = false;
    analyzerState.curr_freq = 0;
    analyzerState.rssi_now = 0.0f;
    analyzerState.last_rssi = 0.0f;
    analyzerFilterVal = 0.0f;
    if (analyzerHoldCount > 0) {
      analyzerHoldCount--;
    }
  }

  analyzerLocked = (analyzerState.rssi_now > analyzerTrigLevel);
  analyzerState.threshold = analyzerTrigLevel;
  if (analyzerState.has_signal) {
    if (!hadSignal) {
      analyzerAddHistory(analyzerState.curr_freq);
    } else {
      uint32_t diff = (analyzerState.curr_freq > prevFreq)
        ? (analyzerState.curr_freq - prevFreq)
        : (prevFreq - analyzerState.curr_freq);
      if (diff >= 300000UL) {
        analyzerAddHistory(analyzerState.curr_freq);
      }
    }
  }
}

void OLED_printAnalyzer() {
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);

  display.setTextSize(2);
  char buf[32];
  if (analyzerState.has_signal && analyzerState.curr_freq > 0) {
    display.fillRect(6, 0, 88, 20, SH110X_WHITE);
    display.setTextColor(SH110X_BLACK);
    snprintf(buf, sizeof(buf), "%03lu.%03lu",
             analyzerState.curr_freq / 1000000UL % 1000UL,
             analyzerState.curr_freq / 1000UL % 1000UL);
  } else {
    display.setTextColor(SH110X_WHITE);
    snprintf(buf, sizeof(buf), "---.---");
  }
  display.setCursor(8, 3);
  display.print(buf);

  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);
  display.setCursor(96, 6);
  display.print("MHz");

  const uint8_t left = 2, right = 66, top = 28;
  uint8_t line = 0;
  for (uint8_t i = 0; i < ANALYZER_HIST_CNT; i++) {
    uint8_t xpos = (i % 2 == 0) ? left : right;
    uint8_t ypos = top + line * 9;
    if (i % 2 == 1) line++;

    display.setCursor(xpos, ypos);
    if (analyzerState.hist_freq[i] > 0) {
      snprintf(buf, sizeof(buf), "%03lu.%03lu",
               analyzerState.hist_freq[i] / 1000000UL % 1000UL,
               analyzerState.hist_freq[i] / 1000UL % 1000UL);
      display.print(buf);
    } else {
      display.print("---.---");
    }

    display.setCursor(xpos + 41, ypos);
    if (analyzerState.hist_count[i] > 0) {
      snprintf(buf, sizeof(buf), "x%u", analyzerState.hist_count[i]);
      display.print(buf);
    } else {
      display.print("MHz");
    }
  }

  display.setCursor(1, 55);
  display.print((int)analyzerTrigLevel);

  analyzerDrawGraph(29, 57);
  display.display();
}

void analyzerDrawGraph(uint8_t x, uint8_t y) {
  const uint8_t width = 95;

  if (analyzerState.rssi_now != 0.0f) {
    float rssi = analyzerState.rssi_now;
    if (rssi > ANALYZER_RSSI_HIGH) rssi = ANALYZER_RSSI_HIGH;
    rssi = (rssi - ANALYZER_RSSI_LOW) / (ANALYZER_RSSI_MUL * ANALYZER_RSSI_GRAPH_SCALE);

    uint8_t bars = 0;
    for (size_t i = 0; i <= (uint8_t)rssi && (x + 2 * i) < (x + width); i++) {
      if ((i + 1) % 4) {
        bars++;
        display.fillRect(x + 2 * i, (y + 4) - bars, 2, bars, SH110X_WHITE);
      }
    }
  }

  if (analyzerState.last_rssi != 0.0f) {
    float last = analyzerState.last_rssi;
    if (last > ANALYZER_RSSI_HIGH) last = ANALYZER_RSSI_HIGH;
    int lastX = (int)((last - ANALYZER_RSSI_LOW) / ANALYZER_RSSI_MUL) * 2;
    if (lastX < width) {
      int lastH = (int)((last - ANALYZER_RSSI_LOW) / (ANALYZER_RSSI_MUL * ANALYZER_RSSI_GRAPH_SCALE)) + 1;
      lastH -= (lastH / 4) + 3;
      display.drawLine(x + lastX + 1, y - lastH, x + lastX + 1, y + 3, SH110X_WHITE);
    }
  }

  float trigPos = (analyzerTrigLevel - ANALYZER_RSSI_LOW) / ANALYZER_RSSI_MUL;
  uint8_t trigX = (uint8_t)((float)x + (2 * trigPos));
  if (trigX < x + width) {
    display.drawPixel(trigX, y + 4, SH110X_WHITE);
    display.drawLine(trigX - 1, y + 5, trigX + 1, y + 5, SH110X_WHITE);
  }

  display.drawLine(x, y + 3, x + width, y + 3, SH110X_WHITE);
}

void OLED_printJammer() {
  display.clearDisplay();
  display.drawBitmap(0, 3, image_Dolphin_Send_bits, 97, 61, SH110X_WHITE);
  display.setTextColor(SH110X_WHITE);
  display.setTextWrap(false);
  display.setCursor(72, 13);
  display.print(String(frequency, 2) + "MHz");
  display.setCursor(65, 42);
  display.print(isJamming ? "Jamming..." : "Press OK");
  if (!isJamming) {
    display.setCursor(65, 51);
    display.print("to start");
  }
  display.display();
}

void startJamming() {
  Serial.println(F("Starting jammer"));
  if (!ensureCC1101Initialized()) return;
  ELECHOUSE_cc1101.setModulation(0);
  ELECHOUSE_cc1101.setMHZ(frequency);
  ELECHOUSE_cc1101.setPA(12);
  ELECHOUSE_cc1101.setDeviation(0);
  ELECHOUSE_cc1101.setRxBW(270.0);
  ELECHOUSE_cc1101.SetTx();
  ELECHOUSE_cc1101.SpiWriteReg(0x3E, 0xFF);
  ELECHOUSE_cc1101.SpiWriteReg(0x35, 0x60);
}

void stopJamming() {
  Serial.println(F("Stopping jammer"));
  ELECHOUSE_cc1101.SpiWriteReg(0x35, 0x00);
  ELECHOUSE_cc1101.SetRx();
  restoreReceiveMode();
}

String getTypeName(emKeys tp) {
  switch (tp) {
    case kUnknown: return F("Unknown");
    case kP12bt: return F("Pre 12bit");
    case k12bt: return F("12bit");
    case k24bt: return F("24bit");
    case k64bt: return F("64bit");
    case kKeeLoq: return F("KeeLoq");
    case kANmotors64: return F("ANmotors");
    case kPrinceton: return F("Princeton");
    case kRcSwitch: return F("RcSwitch");
    case kStarLine: return F("StarLine");
    case kCAME: return F("CAME");
    case kNICE: return F("NICE");
    case kHOLTEK: return F("HOLTEK");
    case kLINEAR: return F("RAW");
    default: return "";
  }
}
